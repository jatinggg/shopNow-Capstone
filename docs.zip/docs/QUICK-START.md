# Quick Start Guide - Deploy Infrastructure

This guide gets you up and running quickly. For detailed explanations, see [DEPLOYMENT-GUIDE.md](./DEPLOYMENT-GUIDE.md).

## Prerequisites

- [ ] AWS CLI configured (`aws configure`)
- [ ] Terraform installed (v1.0+)
- [ ] kubectl installed
- [ ] Ansible installed
- [ ] Jenkins server running on EC2
- [ ] SSH key for EC2 access

---

## Step 1: Create AWS Prerequisites (5 minutes)

```bash
# Create S3 bucket for Terraform state
aws s3 mb s3://jatin-s3-shopnow-tfstate --region eu-west-2

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket jatin-s3-shopnow-tfstate \
  --versioning-configuration Status=Enabled

# Create DynamoDB table for state locking
aws dynamodb create-table \
  --table-name jatin-shopnow-statelock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
  --region eu-west-2

# Create ECR repositories
aws ecr create-repository --repository-name jatinggg-shopnow/frontend --region eu-west-2
aws ecr create-repository --repository-name jatinggg-shopnow/backend --region eu-west-2
aws ecr create-repository --repository-name jatinggg-shopnow/admin --region eu-west-2
```

---

## Step 2: Configure Jenkins with Ansible (10 minutes)

```bash
# Update inventory with your Jenkins IP
cd ansible/inventory
nano hosts
# Replace: jenkins-server ansible_host=YOUR_IP ansible_user=ubuntu ansible_ssh_private_key_file=~/.ssh/your-key.pem

# Test connection
cd ..
ansible jenkins_servers -m ping -i inventory/hosts

# Run playbook (installs Docker, AWS CLI, kubectl, Terraform, Helm)
ansible-playbook -i inventory/hosts playbooks/jenkins-setup.yml
```

---

## Step 3: Deploy AWS Infrastructure with Terraform (20 minutes)

```bash
cd ../eks-tf

# Initialize Terraform
terraform init

# Review plan
terraform plan -var-file=demo.tfvars

# Apply (creates VPC, subnets, NAT, EKS cluster)
terraform apply -var-file=demo.tfvars
# Type 'yes' when prompted
# ☕ This takes 15-20 minutes
```

---

## Step 4: Configure kubectl (2 minutes)

```bash
# Get cluster name from output
terraform output cluster_name

# Configure kubectl
aws eks update-kubeconfig --region eu-west-2 --name jatin-demo-01-jatin-demo-01

# Verify
kubectl get nodes
# Should show 2 nodes in Ready state
```

---

## Step 5: Install Kubernetes Prerequisites (5 minutes)

```bash
cd ../kubernetes

# Install metrics server
kubectl apply -f pre-req/metrics-server.yaml

# Install ingress-nginx controller
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.12.0-beta.0/deploy/static/provider/aws/deploy.yaml

# Wait for ingress controller
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=120s

# Install storage class
kubectl apply -f pre-req/storageclass-gp3.yaml
```

---

## Step 6: Build and Push Docker Images (10 minutes)

```bash
cd ..

# Authenticate to ECR
aws ecr get-login-password --region eu-west-2 | docker login --username AWS --password-stdin $(aws sts get-caller-identity --query Account --output text).dkr.ecr.eu-west-2.amazonaws.com

# Build and push all images
./scripts/build-and-push.sh $(aws sts get-caller-identity --query Account --output text).dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow latest jatin
```

---

## Step 7: Deploy Application to Kubernetes (5 minutes)

```bash
# Create namespace
kubectl create namespace shopnow-demo

# Create ECR secret
kubectl create secret docker-registry ecr-secret \
  --docker-server=$(aws sts get-caller-identity --query Account --output text).dkr.ecr.eu-west-2.amazonaws.com \
  --docker-username=AWS \
  --docker-password=$(aws ecr get-login-password --region eu-west-2) \
  --namespace=shopnow-demo

# Deploy using Kubernetes manifests
kubectl apply -f kubernetes/k8s-manifests/namespace/
kubectl apply -f kubernetes/k8s-manifests/database/
kubectl apply -f kubernetes/k8s-manifests/backend/
kubectl apply -f kubernetes/k8s-manifests/frontend/
kubectl apply -f kubernetes/k8s-manifests/admin/
kubectl apply -f kubernetes/k8s-manifests/ingress/
```

---

## Step 8: Initialize MongoDB (3 minutes)

```bash
# Wait for mongo pod
kubectl wait --for=condition=ready pod mongo-0 -n shopnow-demo --timeout=300s

# Create MongoDB user
kubectl -n shopnow-demo exec -it mongo-0 -- mongosh
```

In the mongo shell:
```javascript
use admin;
db.createUser({
  user: 'shopuser',
  pwd: 'ShopNowPass123',
  roles: [
    { role: 'readWrite', db: 'shopnow' },
    { role: 'dbAdmin', db: 'shopnow' }
  ]
});
exit
```

```bash
# Restart backend
kubectl rollout restart deploy backend -n shopnow-demo
```

---

## Step 9: Verify Deployment (2 minutes)

```bash
# Check all pods (should be Running)
kubectl get pods -n shopnow-demo

# Get Load Balancer URL
export LOAD_BALANCER=$(kubectl get svc -n ingress-nginx -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}')

echo "Frontend:      http://$LOAD_BALANCER/jatin"
echo "Admin:         http://$LOAD_BALANCER/jatin-admin"
echo "Backend API:   http://$LOAD_BALANCER/api/health"
```

Open these URLs in your browser! 🎉

---

## Cleanup (When Done)

```bash
# Delete Kubernetes resources
kubectl delete namespace shopnow-demo

# Destroy infrastructure
cd eks-tf
terraform destroy -var-file=demo.tfvars
```

---

## Troubleshooting

**Issue: S3 bucket already exists**
```bash
# Use a different bucket name in eks-tf/provider.tf
```

**Issue: Pods in ImagePullBackOff**
```bash
# Recreate ECR secret (expires after 12 hours)
kubectl delete secret ecr-secret -n shopnow-demo
# Then recreate it (Step 7)
```

**Issue: kubectl can't connect**
```bash
# Update kubeconfig
aws eks update-kubeconfig --region eu-west-2 --name jatin-demo-01-jatin-demo-01
```

---

## Total Time: ~60 minutes

**That's it!** You now have:
- ✅ VPC with public/private subnets
- ✅ EKS cluster with 2 nodes
- ✅ Fully deployed application
- ✅ Load balancer for external access

For detailed explanations and advanced configurations, see the [complete deployment guide](./DEPLOYMENT-GUIDE.md).
