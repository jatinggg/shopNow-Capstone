# Jenkins Server Resource Analysis - t3.medium with 30GB EBS

## 📊 Your Constraints

- **Instance Type:** t3.medium (2 vCPU, 4GB RAM)
- **EBS Volume:** 30GB maximum
- **Purpose:** Jenkins CI/CD server for building Docker images and deploying to EKS

---

## 💾 Storage Breakdown (30GB Analysis)

### Base System Requirements

| Component | Size | Description |
|-----------|------|-------------|
| **Ubuntu OS** | 5-8 GB | Operating system and base packages |
| **Jenkins** | 1-2 GB | Jenkins installation + plugins |
| **Docker Engine** | 1-2 GB | Docker binaries and dependencies |
| **Tools** | 1 GB | kubectl, Terraform, Helm, AWS CLI |
| **System Reserved** | 2 GB | Swap, temp files, system cache |
| **Subtotal** | **10-15 GB** | Fixed overhead |

### Jenkins Workspace Requirements

| Component | Size | Description |
|-----------|------|-------------|
| **Source Code** | 100-200 MB | Your application code (frontend, backend, admin) |
| **node_modules** | 500 MB - 1 GB | Per build (npm dependencies for all 3 services) |
| **Build Artifacts** | 200-500 MB | Compiled code, temporary files |
| **Subtotal per build** | **~2 GB** | Active workspace |

### Docker Storage

| Component | Size | Description |
|-----------|------|-------------|
| **Base Images** | 1-2 GB | node:18-alpine (~150MB), nginx:alpine (~50MB) |
| **Built Images** | 1-2 GB | Your 3 services (frontend, backend, admin) |
| **Image Layers** | 1-2 GB | Intermediate layers during builds |
| **Subtotal** | **3-6 GB** | Active Docker storage |

---

## ✅ 30GB Feasibility Analysis

### Minimum Required: ~15-23 GB
```
Base System:        10-15 GB
Jenkins Workspace:   2-3 GB
Docker Storage:      3-6 GB
----------------------------
Total:              15-24 GB
```

### Available Headroom: ~5-7 GB

**Verdict: ✅ 30GB IS SUFFICIENT** if you follow strict cleanup practices

---

## ⚠️ Tight Spots & Risks

### When 30GB Might Fill Up:

1. **Multiple Concurrent Builds**
   - Each build needs ~2GB workspace
   - 3 concurrent builds = 6GB

2. **Docker Image Accumulation**
   - Old/dangling images not cleaned
   - Can grow to 10-15 GB quickly

3. **Jenkins Build History**
   - Logs and artifacts from old builds
   - Can accumulate over time

4. **npm/Docker Cache**
   - npm cache: ~500MB-1GB
   - Docker build cache: 2-5 GB

---

## 🛡️ Mitigation Strategies (REQUIRED!)

### 1. Configure Docker Storage Limits

Add to Jenkins server after installation:

```bash
# Create Docker daemon config
sudo mkdir -p /etc/docker
sudo tee /etc/docker/daemon.json << 'EOF'
{
  "storage-driver": "overlay2",
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  },
  "data-root": "/var/lib/docker"
}
EOF

sudo systemctl restart docker
```

**Saves:** 1-2 GB (limits container logs)

---

### 2. Automated Docker Cleanup (CRITICAL!)

Add cron job on Jenkins server:

```bash
# Create cleanup script
sudo tee /usr/local/bin/docker-cleanup.sh << 'EOF'
#!/bin/bash
# Clean up Docker resources to free space

echo "=== Docker Cleanup Started: $(date) ==="

# Remove stopped containers
docker container prune -f

# Remove dangling images (untagged)
docker image prune -f

# Remove unused volumes
docker volume prune -f

# Remove build cache older than 24h
docker buildx prune -f --filter "until=24h"

# Show current usage
echo "=== Current Docker Usage ==="
docker system df

echo "=== Cleanup Complete: $(date) ==="
EOF

chmod +x /usr/local/bin/docker-cleanup.sh

# Add to cron (runs daily at 2 AM)
sudo crontab -l 2>/dev/null | { cat; echo "0 2 * * * /usr/local/bin/docker-cleanup.sh >> /var/log/docker-cleanup.log 2>&1"; } | sudo crontab -
```

**Saves:** 3-5 GB regularly

---

### 3. Jenkins Workspace Cleanup

Configure in Jenkins:

**Option A: Via Jenkins UI**
1. Manage Jenkins → Configure System
2. Find "Workspace Cleanup Plugin" (install if missing)
3. Add post-build action to all jobs: "Delete workspace when build is done"

**Option B: Via Jenkinsfile** (add to your pipelines)
```groovy
pipeline {
    agent any
    
    options {
        // Only keep last 10 builds
        buildDiscarder(logRotator(numToKeepStr: '10'))
        
        // Clean workspace before build
        skipDefaultCheckout(true)
    }
    
    stages {
        stage('Checkout') {
            steps {
                checkout scm
            }
        }
        
        stage('Build') {
            steps {
                // Your build steps
            }
        }
    }
    
    post {
        always {
            // Clean workspace after build
            cleanWs()
        }
    }
}
```

**Saves:** 2-5 GB

---

### 4. npm Cache Management

Add to your Jenkinsfile build stages:

```groovy
stage('Build Docker Images') {
    steps {
        script {
            // Use --no-cache for npm to avoid cache buildup
            sh '''
                docker build \
                  --build-arg NPM_CONFIG_CACHE=/tmp/npm-cache \
                  --no-cache \
                  -t frontend:${BUILD_NUMBER} \
                  ./frontend
            '''
        }
    }
}
```

Or clean npm cache periodically:
```bash
npm cache clean --force
```

**Saves:** 500 MB - 1 GB

---

### 5. Monitor Disk Usage

Add monitoring script:

```bash
# Create disk monitoring script
sudo tee /usr/local/bin/check-disk-space.sh << 'EOF'
#!/bin/bash

THRESHOLD=80
CURRENT=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')

if [ $CURRENT -gt $THRESHOLD ]; then
    echo "WARNING: Disk usage is at ${CURRENT}%"
    echo ""
    echo "=== Top 10 Largest Directories ==="
    du -h --max-depth=1 / 2>/dev/null | sort -rh | head -10
    echo ""
    echo "=== Docker System Usage ==="
    docker system df
    echo ""
    echo "=== Jenkins Workspace Usage ==="
    du -sh /var/lib/jenkins/workspace/* 2>/dev/null | sort -rh | head -5
fi
EOF

chmod +x /usr/local/bin/check-disk-space.sh

# Add to cron (runs hourly)
echo "0 * * * * /usr/local/bin/check-disk-space.sh >> /var/log/disk-check.log 2>&1" | sudo crontab -
```

---

## 📋 Recommended Jenkins Configuration

### Global Jenkins Settings

Add to Jenkins global configuration:

```groovy
// In Manage Jenkins → Configure System

// Discard old builds
Jenkins.instance.getItems().each { item ->
    item.setBuildDiscarder(
        new hudson.tasks.LogRotator(
            -1,    // daysToKeep
            10,    // numToKeep - Keep only last 10 builds
            -1,    // artifactDaysToKeep
            5      // artifactNumToKeep - Keep artifacts for last 5 builds
        )
    )
}
```

---

## 🎯 Optimized Dockerfile Strategies

### Multi-Stage Builds (Smaller Images)

**Before (Large Image):**
```dockerfile
FROM node:18
WORKDIR /app
COPY package*.json ./
RUN npm install  # Includes dev dependencies
COPY . .
RUN npm run build
CMD ["npm", "start"]
# Image size: ~800MB
```

**After (Optimized):**
```dockerfile
# Stage 1: Build
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production  # Production only
COPY . .
RUN npm run build

# Stage 2: Runtime
FROM node:18-alpine
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
COPY package*.json ./
CMD ["npm", "start"]
# Image size: ~200-300MB
```

**Saves:** 500-600 MB per image × 3 = **1.5-2 GB total**

---

## 📊 Expected Usage with Optimizations

| Component | Without Optimization | With Optimization | Savings |
|-----------|---------------------|-------------------|---------|
| Base System | 10-15 GB | 10-15 GB | 0 GB |
| Jenkins Workspace | 5-8 GB | 2-3 GB | 3-5 GB |
| Docker Images | 5-10 GB | 2-4 GB | 3-6 GB |
| Cache/Temp | 3-5 GB | 1-2 GB | 2-3 GB |
| **Total Used** | **23-38 GB** | **15-24 GB** | **8-14 GB** |

**With optimizations: 5-15 GB free space** ✅

---

## 🚨 Emergency Cleanup Commands

If disk fills up mid-build:

```bash
# Emergency cleanup (run as root)
sudo su

# 1. Docker nuclear option
docker system prune -a -f --volumes
# Saves: 5-10 GB

# 2. Clean Jenkins workspaces
rm -rf /var/lib/jenkins/workspace/*
# Saves: 2-5 GB

# 3. Clean package caches
apt-get clean
npm cache clean --force
# Saves: 500 MB - 1 GB

# 4. Clean logs
journalctl --vacuum-time=2d
find /var/log -type f -name "*.log" -mtime +7 -delete
# Saves: 500 MB - 1 GB

# 5. Clear temp files
rm -rf /tmp/*
# Saves: 500 MB - 1 GB
```

---

## ✅ Pre-Flight Checklist for 30GB Setup

Before running builds:

- [ ] Configure Docker daemon with log limits
- [ ] Set up daily Docker cleanup cron job
- [ ] Configure Jenkins build retention (keep last 10)
- [ ] Enable workspace cleanup in Jenkinsfiles
- [ ] Optimize Dockerfiles with multi-stage builds
- [ ] Set up disk space monitoring
- [ ] Test emergency cleanup procedure
- [ ] Document the 30GB constraint for team

---

## 💡 Alternative: Use ECR Directly

Instead of storing images on Jenkins server:

```groovy
// In Jenkinsfile
stage('Build and Push') {
    steps {
        sh '''
            # Build image
            docker build -t myapp:${BUILD_NUMBER} .
            
            # Push to ECR immediately
            docker tag myapp:${BUILD_NUMBER} ${ECR_URL}/myapp:${BUILD_NUMBER}
            docker push ${ECR_URL}/myapp:${BUILD_NUMBER}
            
            # Remove local image immediately after push
            docker rmi myapp:${BUILD_NUMBER}
            docker rmi ${ECR_URL}/myapp:${BUILD_NUMBER}
        '''
    }
}
```

**Benefit:** Don't keep images on Jenkins server at all!

---

## 🎯 RAM Consideration (t3.medium = 4GB)

4GB RAM is also tight for builds:

**Memory Breakdown:**
- OS: 500 MB
- Jenkins: 1-1.5 GB
- Docker builds: 1-2 GB per concurrent build
- Available: ~1 GB buffer

**Recommendation:**
```bash
# Configure Jenkins heap size
sudo tee -a /etc/default/jenkins << 'EOF'
JAVA_ARGS="-Xmx1536m -Xms512m"
EOF

sudo systemctl restart jenkins
```

**Limit concurrent builds:**
- Jenkins → Manage Jenkins → Configure System
- Set "# of executors" = **1** (only 1 build at a time)

---

## 📝 Summary

### ✅ 30GB IS ENOUGH IF:

1. ✅ You implement Docker cleanup (daily cron)
2. ✅ You use multi-stage Dockerfiles
3. ✅ You clean Jenkins workspaces after builds
4. ✅ You keep only last 10 build histories
5. ✅ You limit concurrent builds to 1
6. ✅ You push images to ECR and delete locally

### ⚠️ 30GB MIGHT NOT BE ENOUGH IF:

1. ❌ You don't clean up Docker images
2. ❌ You run multiple concurrent builds
3. ❌ You keep large build artifacts
4. ❌ You don't optimize Dockerfiles

---

## 🎓 For Your Assignment

Document the resource optimization strategies:

1. **Screenshots to include:**
   - `df -h` showing disk usage
   - `docker system df` showing Docker usage
   - Jenkins configuration for build retention
   - Cron jobs for automated cleanup

2. **Cost Optimization Section:**
   - "Used t3.medium (2 vCPU, 4GB RAM) instead of t3.large"
   - "Optimized Docker images to 200-300MB from 800MB"
   - "Implemented automated cleanup saving 5-10GB daily"

3. **Best Practices:**
   - Resource-constrained environment management
   - Automated cleanup strategies
   - Multi-stage Docker builds

---

**Verdict: 30GB on t3.medium is SUFFICIENT** with proper optimization! 🚀

**Most critical steps:**
1. Daily Docker cleanup cron job
2. Jenkins workspace cleanup in Jenkinsfiles
3. Multi-stage Dockerfiles
4. Limit to 1 concurrent build
