# Quick Start - Using Your Existing Setup

## ✅ What You Already Have
- Jenkins server running on EC2
- Docker images in ECR (frontend, backend, admin)
- S3 bucket: `jatin-s3-shopnow-tfstate`
- DynamoDB table: `jatin-shopnow-statelock`

---

## 🎯 What to Do Next

### Option 1: Use Different Terraform State Key (RECOMMENDED)

**Why:** Keeps your existing state safe, creates independent deployment

**How:**
1. Edit [`eks-tf/provider.tf`](file:///d:/HeroVired/shopNow-Capstone/eks-tf/provider.tf)
2. Change line 22 from:
   ```hcl
   key = "terraform/terraform.tfstate"
   ```
   To:
   ```hcl
   key = "capstone-eks/terraform.tfstate"
   ```

**Benefit:** Your old infrastructure (if any) remains intact

---

### Option 2: Delete Existing State Files (FRESH START)

**Why:** Start completely fresh, no conflicts

**How:**
```bash
# List current files
aws s3 ls s3://jatin-s3-shopnow-tfstate/terraform/ --recursive

# Delete old state
aws s3 rm s3://jatin-s3-shopnow-tfstate/terraform/terraform.tfstate
aws s3 rm s3://jatin-s3-shopnow-tfstate/terraform/terraform.tfstate.backup

# DynamoDB locks expire automatically, no action needed
```

**Warning:** ⚠️ This breaks the link to any existing infrastructure managed by that state

---

## 🛠️ Jenkins Tools Verification

**You don't need to run Ansible if Jenkins already has these tools:**

```bash
# SSH into your Jenkins server
ssh ubuntu@<your-jenkins-ip>

# Check if tools exist:
docker --version        # Need: 20.x or higher
aws --version          # Need: 2.x
kubectl version --client  # Need: 1.28+
git --version          # Need: any version

# If ALL exist → Skip Ansible entirely ✅
# If ANY missing → Run Ansible playbook from your local machine:
# ansible-playbook -i ansible/inventory/hosts ansible/playbooks/jenkins-setup.yml
```

**jenkins-setup.yml Purpose:**
- It was created to satisfy Sprint 3 requirement (Ansible for configuration management)
- It's a demonstration of automation, not mandatory for deployment
- **Skip it if your Jenkins already has the tools**

---

## 🚀 Deployment Steps (30-40 minutes)

### Step 1: Update Terraform State Path (30 seconds)

Choose Option 1 or Option 2 above, then:

```bash
cd eks-tf
# Verify provider.tf has correct state path
cat provider.tf | grep key
```

---

### Step 2: Deploy Infrastructure (20 minutes)

```bash
cd eks-tf

# Initialize Terraform
terraform init

# Preview changes
terraform plan -var-file=demo.tfvars

# Create infrastructure
terraform apply -var-file=demo.tfvars
# Type 'yes' when prompted

# ☕ Wait 15-20 minutes for EKS cluster creation

# Get cluster name
terraform output cluster_name

# Configure kubectl
aws eks update-kubeconfig --region eu-west-2 --name $(terraform output -raw cluster_name)

# Verify connectivity
kubectl get nodes
# Should show 2 nodes in Ready state
```

---

### Step 3: Install K8s Prerequisites (5 minutes)

```bash
cd ..  # Back to project root

# Metrics server
kubectl apply -f kubernetes/pre-req/metrics-server.yaml

# Ingress controller
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.12.0-beta.0/deploy/static/provider/aws/deploy.yaml

# Wait for ingress to be ready
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=120s

# Storage class
kubectl apply -f kubernetes/pre-req/storageclass-gp3.yaml
```

---

### Step 4: Deploy Application with Your Existing Images (5 minutes)

```bash
# Create namespace
kubectl create namespace shopnow-demo

# Create ECR secret (refreshes every 12 hours)
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
kubectl create secret docker-registry ecr-secret \
  --docker-server=${ACCOUNT_ID}.dkr.ecr.eu-west-2.amazonaws.com \
  --docker-username=AWS \
  --docker-password=$(aws ecr get-login-password --region eu-west-2) \
  --namespace=shopnow-demo

# Deploy all resources
kubectl apply -f kubernetes/k8s-manifests/namespace/
kubectl apply -f kubernetes/k8s-manifests/database/
kubectl apply -f kubernetes/k8s-manifests/backend/
kubectl apply -f kubernetes/k8s-manifests/frontend/
kubectl apply -f kubernetes/k8s-manifests/admin/
kubectl apply -f kubernetes/k8s-manifests/ingress/

# Check deployment status
kubectl get pods -n shopnow-demo --watch
# Wait until all pods show "Running"
# Press Ctrl+C to exit watch
```

---

### Step 5: Initialize MongoDB (3 minutes)

```bash
# Wait for mongo pod to be ready
kubectl wait --for=condition=ready pod mongo-0 -n shopnow-demo --timeout=300s

# Create MongoDB user
kubectl -n shopnow-demo exec -it mongo-0 -- mongosh
```

**In the MongoDB shell:**
```javascript
use admin;
db.createUser({
  user: 'shopuser',
  pwd: 'ShopNowPass123',
  roles: [
    { role: 'readWrite', db: 'shopnow' },
    { role: 'dbAdmin', db: 'shopnow' }
  ]
});
exit
```

**Back in your terminal:**
```bash
# Restart backend to connect to MongoDB
kubectl rollout restart deploy backend -n shopnow-demo
```

---

### Step 6: Access Application (1 minute)

```bash
# Get Load Balancer DNS
LOAD_BALANCER=$(kubectl get svc -n ingress-nginx -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}')

echo ""
echo "🎉 Deployment Complete!"
echo ""
echo "Frontend:      http://$LOAD_BALANCER/jatin"
echo "Admin Panel:   http://$LOAD_BALANCER/jatin-admin"
echo "Backend API:   http://$LOAD_BALANCER/api/health"
echo ""
```

**Open these URLs in your browser!**

---

## 🧪 Verification Commands

```bash
# Check all pods are running
kubectl get pods -n shopnow-demo

# Check services
kubectl get svc -n shopnow-demo

# Check ingress
kubectl get ingress -n shopnow-demo

# Test backend health
curl http://$LOAD_BALANCER/api/health

# View pod logs
kubectl logs -f deployment/backend -n shopnow-demo
kubectl logs -f deployment/frontend -n shopnow-demo
kubectl logs -f deployment/admin -n shopnow-demo
```

---

## 🔄 Updating Application (When You Rebuild Images)

When you rebuild Docker images and push to ECR:

```bash
# Option 1: Restart deployments to pull latest images
kubectl rollout restart deploy frontend -n shopnow-demo
kubectl rollout restart deploy backend -n shopnow-demo
kubectl rollout restart deploy admin -n shopnow-demo

# Option 2: Update image tags in manifests and reapply
kubectl set image deploy/frontend frontend=<ecr-url>/frontend:v2.0 -n shopnow-demo
kubectl set image deploy/backend backend=<ecr-url>/backend:v2.0 -n shopnow-demo
kubectl set image deploy/admin admin=<ecr-url>/admin:v2.0 -n shopnow-demo
```

---

## 🧹 Cleanup (When Done)

```bash
# Delete Kubernetes resources
kubectl delete namespace shopnow-demo

# Destroy infrastructure
cd eks-tf
terraform destroy -var-file=demo.tfvars
# Type 'yes' when prompted

# ⏱ Takes 10-15 minutes
```

---

## ❓ FAQ

**Q: Do I need to rebuild Docker images?**
A: No! Your existing images in ECR will work. The K8s manifests should already reference them.

**Q: Do I need to run Ansible?**
A: Only if your Jenkins is missing Docker, AWS CLI, kubectl, or Git. Check first with the verification commands above.

**Q: Can I use my existing S3 bucket?**
A: Yes! Just change the state file key in provider.tf to avoid conflicts (Option 1), or delete old state (Option 2).

**Q: Will this conflict with my existing infrastructure?**
A: No, if you:
- Use a different Terraform state key (Option 1), OR
- Delete old state and start fresh (Option 2), OR
- Are creating in a different AWS region/account

**Q: Where does Jenkins fit in?**
A: Jenkins is for CI/CD automation:
- CI: Build Docker images when code changes → push to ECR
- CD: Deploy updated images to Kubernetes
- Infrastructure: (Optional) Run Terraform from Jenkins
For now, you're running Terraform manually from your machine, which is fine for the capstone.

---

**Total Time: ~35 minutes to full deployment** ⏱

**Next Step:** Choose Option 1 or 2 for Terraform state, then run Step 2!
