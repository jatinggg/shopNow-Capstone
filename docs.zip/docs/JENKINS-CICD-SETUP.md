# Service-Specific CI/CD Pipelines - Setup Guide

## 📋 Overview

This guide shows how to configure Jenkins to run separate CI/CD pipelines for each service (backend, frontend, admin) that only trigger when changes are detected in their respective directories.

---

## 🎯 What You Get

Three independent pipelines:
- **`Jenkinsfile.cicd.backend`** - Triggers only on `backend/` changes
- **`Jenkinsfile.cicd.frontend`** - Triggers only on `frontend/` changes  
- **`Jenkinsfile.cicd.admin`** - Triggers only on `admin/` changes

Each pipeline:
1. ✅ Checks for directory-specific changes
2. ✅ Skips if no changes (saves resources!)
3. ✅ Builds Docker image
4. ✅ Pushes to ECR
5. ✅ Deploys to Kubernetes
6. ✅ Verifies deployment
7. ✅ Cleans up workspace (saves disk space)

---

## 🔧 Jenkins Setup (Two Options)

### Option 1: Multibranch Pipeline (RECOMMENDED)

**Best for:** Automatic discovery, branch support, webhooks

#### Step 1: Install Plugins

1. Go to **Manage Jenkins** → **Manage Plugins**
2. Install these plugins:
   - Git
   - Pipeline
   - Multibranch Scan Webhook Trigger (optional, for webhooks)

#### Step 2: Create Multibranch Pipeline Jobs

For each service, create a separate job:

**For Backend:**
1. Click **New Item**
2. Name: `ShopNow-Backend-CICD`
3. Type: **Multibranch Pipeline**
4. Click **OK**

5. **Branch Sources** section:
   - Add source: **Git**
   - Project Repository: `https://github.com/<your-username>/shopNow-Capstone.git`
   - Credentials: Add your GitHub credentials

6. **Build Configuration** section:
   - Mode: **by Jenkinsfile**
   - Script Path: `jenkins/Jenkinsfile.cicd.backend`

7. **Scan Multibranch Pipeline Triggers** section:
   - Check **Periodically if not otherwise run**
   - Interval: **1 minute** (or configure webhook)

8. Click **Save**

9. Click **Scan Multibranch Pipeline Now**

**Repeat for Frontend:**
- Name: `ShopNow-Frontend-CICD`
- Script Path: `jenkins/Jenkinsfile.cicd.frontend`

**Repeat for Admin:**
- Name: `ShopNow-Admin-CICD`
- Script Path: `jenkins/Jenkinsfile.cicd.admin`

---

### Option 2: Pipeline Jobs (Simpler Setup)

**Best for:** Single branch, simpler configuration

#### Create Three Pipeline Jobs

**For Backend:**
1. Click **New Item**
2. Name: `ShopNow-Backend-CICD`
3. Type: **Pipeline**
4. Click **OK**

5. **Pipeline** section:
   - Definition: **Pipeline script from SCM**
   - SCM: **Git**
   - Repository URL: `https://github.com/<your-username>/shopNow-Capstone.git`
   - Credentials: Add your GitHub credentials
   - Branch Specifier: `*/main` (or your branch)
   - Script Path: `jenkins/Jenkinsfile.cicd.backend`

6. **Build Triggers** section:
   - Check **Poll SCM**
   - Schedule: `H/5 * * * *` (every 5 minutes)
   - OR configure GitHub webhook

7. Click **Save**

**Repeat for Frontend and Admin** with their respective Jenkinsfiles.

---

## 🔗 GitHub Webhook Configuration (OPTIONAL)

For instant builds when you push code:

### Step 1: Create Jenkins Webhook URL

Get your Jenkins URL:
```
http://<your-jenkins-server>:8080/github-webhook/
```

### Step 2: Configure GitHub Webhook

1. Go to your GitHub repository
2. Settings → Webhooks → Add webhook
3. Payload URL: `http://<your-jenkins-server>:8080/github-webhook/`
4. Content type: `application/json`
5. Trigger: **Just the push event**
6. Click **Add webhook**

### Step 3: Update Jenkins Job

In each pipeline job:
1. **Build Triggers** section
2. Check **GitHub hook trigger for GITScm polling**
3. Save

**Now:** Every git push triggers all 3 pipelines, but only the one with changes will actually build!

---

## 📊 How Change Detection Works

### The Logic

Each Jenkinsfile has this stage:

```groovy
stage('Check for Changes') {
    steps {
        script {
            def changes = sh(
                script: """
                    if [ "\${GIT_PREVIOUS_COMMIT}" = "" ]; then
                        echo "true"
                    else
                        git diff --name-only \${GIT_PREVIOUS_COMMIT} \${GIT_COMMIT} | grep "^${SERVICE_DIR}/" || echo "false"
                    fi
                """,
                returnStdout: true
            ).trim()
            
            if (changes == "false") {
                echo "⏭️  No changes in ${SERVICE_DIR}/ directory. Skipping build."
                currentBuild.result = 'NOT_BUILT'
                error("No changes detected - skipping pipeline")
            }
        }
    }
}
```

### What It Does

1. **Compares commits:**
   - Gets list of changed files between `GIT_PREVIOUS_COMMIT` and `GIT_COMMIT`
   
2. **Checks directory:**
   - Looks for changes in the service directory (e.g., `backend/`)
   
3. **Decision:**
   - If changes found → Continue with build
   - If no changes → Mark as `NOT_BUILT` and skip

### Examples

**Scenario 1: Change in Backend**
```bash
# Files changed in commit
modified: backend/server.js
modified: backend/package.json

# Result
Backend pipeline: ✅ BUILDS
Frontend pipeline: ⏭️  SKIPPED (NOT_BUILT)
Admin pipeline: ⏭️  SKIPPED (NOT_BUILT)
```

**Scenario 2: Change in Frontend + Docs**
```bash
# Files changed in commit
modified: frontend/src/App.js
modified: README.md

# Result
Backend pipeline: ⏭️  SKIPPED
Frontend pipeline: ✅ BUILDS
Admin pipeline: ⏭️  SKIPPED
```

**Scenario 3: Change in Multiple Services**
```bash
# Files changed in commit
modified: backend/server.js
modified: frontend/src/App.js

# Result
Backend pipeline: ✅ BUILDS
Frontend pipeline: ✅ BUILDS
Admin pipeline: ⏭️  SKIPPED
```

**Scenario 4: Change ONLY in docs/kubernetes**
```bash
# Files changed in commit
modified: docs/DEPLOYMENT-GUIDE.md
modified: kubernetes/k8s-manifests/ingress/ingress.yaml

# Result
Backend pipeline: ⏭️  SKIPPED
Frontend pipeline: ⏭️  SKIPPED
Admin pipeline: ⏭️  SKIPPED
```

---

## 🧪 Testing the Setup

### Test 1: Verify Change Detection

```bash
# 1. Make change in backend only
echo "// test change" >> backend/server.js
git add backend/server.js
git commit -m "test: backend change detection"
git push

# Expected: Only backend pipeline runs
```

Check Jenkins:
- Backend job: Should show build #X with "Changes detected" message
- Frontend job: Should show "NOT_BUILT" or skipped
- Admin job: Should show "NOT_BUILT" or skipped

### Test 2: Verify Independent Triggers

```bash
# 2. Make change in frontend only
echo "// test change" >> frontend/src/App.js
git add frontend/src/App.js
git commit -m "test: frontend change detection"
git push

# Expected: Only frontend pipeline runs
```

### Test 3: Verify Multiple Services

```bash
# 3. Make changes in multiple services
echo "// test" >> backend/server.js
echo "// test" >> admin/src/App.js
git add backend/server.js admin/src/App.js
git commit -m "test: multi-service changes"
git push

# Expected: Backend + Admin pipelines run, Frontend skipped
```

---

## 📁 Directory Structure Requirements

For the change detection to work correctly, your repo structure must be:

```
shopNow-Capstone/
├── backend/
│   ├── Dockerfile
│   ├── server.js
│   └── package.json
├── frontend/
│   ├── Dockerfile
│   ├── src/
│   └── package.json
├── admin/
│   ├── Dockerfile
│   ├── src/
│   └── package.json
├── jenkins/
│   ├── Jenkinsfile.cicd.backend
│   ├── Jenkinsfile.cicd.frontend
│   └── Jenkinsfile.cicd.admin
└── kubernetes/
    └── k8s-manifests/
        ├── backend/
        ├── frontend/
        └── admin/
```

**Critical:** Each service must be in its own top-level directory.

---

## ⚙️ Environment Variables

Each Jenkinsfile needs these environment variables configured in Jenkins:

### Option A: Global Environment Variables (Easier)

1. Go to **Manage Jenkins** → **Configure System**
2. Scroll to **Global properties**
3. Check **Environment variables**
4. Add:
   - Name: `AWS_ACCOUNT_ID`, Value: `<your-12-digit-account-id>`

### Option B: Job-Level Variables

Already defined in each Jenkinsfile:
```groovy
environment {
    AWS_REGION = 'eu-west-2'
    ECR_REGISTRY = "${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
    ECR_REPOSITORY = 'jatinggg-shopnow/backend'  // Changes per service
    K8S_NAMESPACE = 'shopnow-demo'
}
```

---

## 🔐 Required Jenkins Credentials

Configure in **Manage Jenkins** → **Manage Credentials**:

### 1. AWS Credentials (for ECR and EKS)

The Jenkins server needs AWS CLI configured:

```bash
# On Jenkins server, as jenkins user
sudo su - jenkins
aws configure
# Enter:
#   AWS Access Key ID
#   AWS Secret Access Key
#   Default region: eu-west-2
#   Default output: json
```

### 2. GitHub Credentials (for private repos)

If your repo is private:
1. **Manage Credentials** → **Global** → **Add Credentials**
2. Kind: **Username with password**
3. Username: Your GitHub username
4. Password: GitHub Personal Access Token
5. ID: `github-credentials`

---

## 🎛️ Pipeline Configuration Tips

### Limit Concurrent Builds per Service

To save resources on t3.medium:

1. Edit each pipeline job
2. Check **Do not allow concurrent builds**
3. Save

This prevents the same service from building twice simultaneously.

### Build History Retention

Already configured in Jenkinsfiles:
```groovy
options {
    buildDiscarder(logRotator(numToKeepStr: '10'))
}
```

Keeps only last 10 builds per service.

---

## 🔍 Troubleshooting

### Issue: All Pipelines Run Even Without Changes

**Cause:** Change detection not working

**Fix:** Ensure SCM is configured correctly:
```bash
# Verify in job configuration:
- ✅ SCM is set to Git
- ✅ Repository URL is correct
- ✅ Branch is specified correctly
```

### Issue: Pipeline Shows "NOT_BUILT" But Should Build

**Cause:** Directory path mismatch

**Fix:** Check `SERVICE_DIR` environment variable:
```groovy
// In Jenkinsfile
environment {
    SERVICE_DIR = 'backend'  // Must match actual directory name
}
```

### Issue: "AWS CLI Not Found" Error

**Cause:** AWS CLI not installed on Jenkins server

**Fix:**
```bash
# Run Ansible playbook
ansible-playbook -i ansible/inventory/hosts ansible/playbooks/jenkins-setup.yml
```

### Issue: "kubectl: command not found"

**Cause:** kubectl not installed

**Fix:** Same as above - run Ansible playbook

### Issue: ECR Push Fails with "denied: Your authorization token has expired"

**Cause:** ECR token expires after 12 hours

**Fix:** Already handled in Jenkinsfile:
```groovy
// Automatically re-authenticates on each build
aws ecr get-login-password --region ${AWS_REGION} | \
    docker login --username AWS --password-stdin ${ECR_REGISTRY}
```

---

## 📊 Expected Build Times

On t3.medium (2 vCPU, 4GB RAM):

| Stage | Backend | Frontend | Admin |
|-------|---------|----------|-------|
| Check Changes | 5s | 5s | 5s |
| Initialize | 3s | 3s | 3s |
| Build Docker | 2-3 min | 2-3 min | 2-3 min |
| Push to ECR | 1-2 min | 1-2 min | 1-2 min |
| Deploy to K8s | 2-3 min | 2-3 min | 2-3 min |
| Verify | 30s | 30s | 30s |
| **Total** | **6-9 min** | **6-9 min** | **6-9 min** |

**With all 3 running sequentially:** 18-27 minutes total

---

## 🎯 Best Practices

1. **One commit = One service**
   - When possible, separate commits by service
   - Reduces unnecessary builds

2. **Use descriptive commit messages**
   ```bash
   git commit -m "backend: fix authentication bug"
   git commit -m "frontend: update homepage layout"
   ```

3. **Test locally before pushing**
   - Build Docker image locally
   - Test with `docker run`
   - Then push to trigger pipeline

4. **Monitor disk usage**
   ```bash
   # On Jenkins server
   df -h /
   docker system df
   ```

5. **Review build logs**
   - Check console output for each build
   - Look for warnings or optimization opportunities

---

## ✅ Verification Checklist

After setup, verify:

- [ ] All 3 pipeline jobs created in Jenkins
- [ ] SCM polling or webhook configured
- [ ] AWS credentials configured on Jenkins server
- [ ] kubectl can connect to EKS cluster
- [ ] Docker can push to ECR
- [ ] Change detection works (test with commit)
- [ ] Workspace cleanup happens after build
- [ ] Only changed services build

---

## 📝 Summary

**You now have:**
- ✅ 3 independent CI/CD pipelines
- ✅ Intelligent change detection (saves resources!)
- ✅ Automatic ECR push
- ✅ Automatic K8s deployment
- ✅ Workspace cleanup (saves disk space)
- ✅ Build history retention

**Next Steps:**
1. Set up the Jenkins jobs following this guide
2. Test with a small commit to each service
3. Monitor first builds
4. Configure webhooks for instant builds (optional)

**Your Jenkins server will now only build what changes** - perfect for your t3.medium resource constraints! 🚀
