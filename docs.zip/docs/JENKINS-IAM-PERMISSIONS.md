# Jenkins Server - IAM Permissions & Configuration Guide

## 🎯 Overview

For Jenkins to perform CI/CD operations with GitHub webhooks and AWS services, you need:

1. **AWS IAM Role/Policy** for the Jenkins EC2 instance
2. **Security Group** configuration to receive GitHub webhooks
3. **Jenkins Credentials** for AWS and GitHub
4. **GitHub Webhook** configuration

---

## 1️⃣ AWS IAM Policy for Jenkins

### Recommended Approach: IAM Role with Instance Profile

**Create an IAM role and attach it to your Jenkins EC2 instance.**

### Option A: Full Policy (All Permissions)

Create a custom IAM policy named `JenkinsServerPolicy`:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ECRFullAccess",
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken",
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:GetRepositoryPolicy",
        "ecr:DescribeRepositories",
        "ecr:ListImages",
        "ecr:DescribeImages",
        "ecr:BatchGetImage",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:PutImage",
        "ecr:CreateRepository"
      ],
      "Resource": "*"
    },
    {
      "Sid": "EKSAccess",
      "Effect": "Allow",
      "Action": [
        "eks:DescribeCluster",
        "eks:ListClusters",
        "eks:DescribeNodegroup",
        "eks:ListNodegroups"
      ],
      "Resource": "*"
    },
    {
      "Sid": "STSAccess",
      "Effect": "Allow",
      "Action": [
        "sts:GetCallerIdentity"
      ],
      "Resource": "*"
    },
    {
      "Sid": "S3ArtifactStorage",
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::your-jenkins-artifacts-bucket/*",
        "arn:aws:s3:::your-jenkins-artifacts-bucket"
      ]
    }
  ]
}
```

### Option B: Least Privilege Policy (Recommended)

If you want to restrict to specific resources:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ECRAuthToken",
      "Effect": "Allow",
      "Action": [
        "ecr:GetAuthorizationToken"
      ],
      "Resource": "*"
    },
    {
      "Sid": "ECRRepositoryAccess",
      "Effect": "Allow",
      "Action": [
        "ecr:BatchCheckLayerAvailability",
        "ecr:GetDownloadUrlForLayer",
        "ecr:BatchGetImage",
        "ecr:PutImage",
        "ecr:InitiateLayerUpload",
        "ecr:UploadLayerPart",
        "ecr:CompleteLayerUpload",
        "ecr:DescribeImages",
        "ecr:ListImages"
      ],
      "Resource": "arn:aws:ecr:eu-west-2:YOUR_ACCOUNT_ID:repository/jatin-capstone"
    },
    {
      "Sid": "EKSDescribeCluster",
      "Effect": "Allow",
      "Action": [
        "eks:DescribeCluster",
        "eks:ListClusters"
      ],
      "Resource": "arn:aws:eks:eu-west-2:YOUR_ACCOUNT_ID:cluster/*"
    },
    {
      "Sid": "STSGetCallerIdentity",
      "Effect": "Allow",
      "Action": [
        "sts:GetCallerIdentity"
      ],
      "Resource": "*"
    }
  ]
}
```

### How to Apply the IAM Policy

#### Step 1: Create IAM Role

```bash
# Using AWS CLI
aws iam create-role \
    --role-name JenkinsServerRole \
    --assume-role-policy-document '{
      "Version": "2012-10-17",
      "Statement": [
        {
          "Effect": "Allow",
          "Principal": {
            "Service": "ec2.amazonaws.com"
          },
          "Action": "sts:AssumeRole"
        }
      ]
    }'
```

Or via AWS Console:
1. Go to **IAM → Roles → Create role**
2. Select **AWS service** → **EC2**
3. Click **Next**

#### Step 2: Attach Policy to Role

```bash
# Create the policy
aws iam create-policy \
    --policy-name JenkinsServerPolicy \
    --policy-document file://jenkins-policy.json

# Attach to role
aws iam attach-role-policy \
    --role-name JenkinsServerRole \
    --policy-arn arn:aws:iam::YOUR_ACCOUNT_ID:policy/JenkinsServerPolicy
```

Or via AWS Console:
1. **IAM → Policies → Create policy**
2. Paste the JSON from above
3. Name it `JenkinsServerPolicy`
4. Go to **Roles → JenkinsServerRole → Attach policies**
5. Select `JenkinsServerPolicy`

#### Step 3: Create Instance Profile

```bash
# Create instance profile
aws iam create-instance-profile \
    --instance-profile-name JenkinsServerInstanceProfile

# Add role to instance profile
aws iam add-role-to-instance-profile \
    --instance-profile-name JenkinsServerInstanceProfile \
    --role-name JenkinsServerRole
```

#### Step 4: Attach to Jenkins EC2 Instance

```bash
# Attach instance profile to EC2
aws ec2 associate-iam-instance-profile \
    --instance-id i-YOUR_INSTANCE_ID \
    --iam-instance-profile Name=JenkinsServerInstanceProfile
```

Or via AWS Console:
1. **EC2 → Instances → Select Jenkins instance**
2. **Actions → Security → Modify IAM role**
3. Select `JenkinsServerRole`
4. Click **Update IAM role**

---

## 2️⃣ Security Group Configuration

### For GitHub Webhooks

Your Jenkins server must be **publicly accessible** on port `8080` (or your Jenkins port) to receive webhooks from GitHub.

#### Security Group Inbound Rules

```
Type            Protocol    Port    Source              Description
HTTP            TCP         8080    0.0.0.0/0           Jenkins UI (if using HTTP)
HTTPS           TCP        443      0.0.0.0/0           Jenkins UI (if using HTTPS)
SSH             TCP         22      YOUR_IP/32          SSH access (restrict to your IP)
```

> **Security Note**: If you don't want Jenkins publicly accessible, you can:
> 1. Use **GitHub Actions** to trigger Jenkins via internal API
> 2. Use **AWS API Gateway + Lambda** to proxy webhooks
> 3. Use **Smee.io** or **ngrok** for webhook forwarding (dev only)

#### Configure via AWS CLI

```bash
# Get your security group ID
SG_ID=$(aws ec2 describe-instances \
    --instance-ids i-YOUR_INSTANCE_ID \
    --query 'Reservations[0].Instances[0].SecurityGroups[0].GroupId' \
    --output text)

# Allow HTTP from anywhere (for webhooks)
aws ec2 authorize-security-group-ingress \
    --group-id $SG_ID \
    --protocol tcp \
    --port 8080 \
    --cidr 0.0.0.0/0
```

#### GitHub Webhook IP Ranges (Optional - More Secure)

Instead of `0.0.0.0/0`, you can restrict to GitHub's webhook IPs:

```bash
# Get GitHub Meta API for webhook IPs
curl https://api.github.com/meta | jq -r '.hooks[]'

# Example output:
# 140.82.112.0/20
# 143.55.64.0/20
# 192.30.252.0/22
# 185.199.108.0/22

# Add rules for each CIDR
aws ec2 authorize-security-group-ingress \
    --group-id $SG_ID \
    --protocol tcp \
    --port 8080 \
    --cidr 140.82.112.0/20

# Repeat for other CIDRs...
```

---

## 3️⃣ Jenkins Credentials Configuration

### GitHub Credentials

You need to configure GitHub credentials in Jenkins for:
1. **Webhook authentication** (optional but recommended)
2. **Cloning private repositories**

#### Generate GitHub Personal Access Token (PAT)

1. Go to **GitHub → Settings → Developer settings → Personal access tokens → Tokens (classic)**
2. Click **Generate new token (classic)**
3. Name: `Jenkins Webhook Token`
4. Select scopes:
   - `repo` (if private repo)
   - `admin:repo_hook` (for webhook management)
5. Click **Generate token**
6. **Copy the token** (you won't see it again!)

#### Add to Jenkins

1. Go to **Jenkins → Manage Jenkins → Credentials**
2. Click **(global)** domain
3. Click **Add Credentials**
4. Fill in:
   - **Kind**: `Username with password`
   - **Username**: Your GitHub username
   - **Password**: Paste the PAT
   - **ID**: `github-pat`
   - **Description**: `GitHub Personal Access Token`
5. Click **Create**

### AWS Credentials (Optional, if not using IAM role)

If you didn't attach IAM role to EC2, you can add AWS credentials manually:

1. **Jenkins → Manage Jenkins → Credentials**
2. Click **Add Credentials**
3. Fill in:
   - **Kind**: `AWS Credentials`
   - **ID**: `aws-credentials`
   - **Access Key ID**: Your AWS Access Key
   - **Secret Access Key**: Your AWS Secret Key
   - **Description**: `AWS Credentials for ECR/EKS`
4. Click **Create**

> **⚠️ Warning**: Using IAM roles is more secure than storing AWS keys in Jenkins!

---

## 4️⃣ Jenkins Global Configuration

### Set AWS Account ID as Environment Variable

1. Go to **Jenkins → Manage Jenkins → System**
2. Scroll to **Global properties**
3. Check **Environment variables**
4. Click **Add**
   - **Name**: `AWS_ACCOUNT_ID`
   - **Value**: Your AWS Account ID (e.g., `123456789012`)
5. Click **Save**

### Install Required Jenkins Plugins

Go to **Manage Jenkins → Plugins → Available plugins**

Install:
- ✅ **Git Plugin**
- ✅ **GitHub Plugin**
- ✅ **GitHub Branch Source Plugin**
- ✅ **Pipeline Plugin**
- ✅ **Docker Pipeline Plugin**
- ✅ **CloudBees AWS Credentials Plugin**

---

## 5️⃣ GitHub Webhook Configuration

### Option 1: Manual Webhook Setup

1. Go to your GitHub repo → **Settings → Webhooks**
2. Click **Add webhook**
3. Fill in:
   - **Payload URL**: `http://YOUR_JENKINS_PUBLIC_IP:8080/github-webhook/`
   - **Content type**: `application/json`
   - **Secret**: (optional) Generate a secret for security
   - **Which events**: Select `Just the push event`
   - **Active**: ✅ Checked
4. Click **Add webhook**

### Option 2: Auto-Configure via Jenkins GitHub Plugin

If you configured GitHub credentials in Jenkins:

1. Go to your Jenkins job → **Configure**
2. Under **Build Triggers**, check:
   - ✅ **GitHub hook trigger for GITScm polling**
3. Save

Jenkins will automatically register the webhook!

### Webhook Secret (Security Best Practice)

To verify webhooks are from GitHub:

1. **Generate a secret**:
   ```bash
   openssl rand -hex 20
   ```

2. **Add to GitHub webhook** (in the Secret field)

3. **Add to Jenkins**:
   - **Manage Jenkins → System**
   - Find **GitHub** section
   - Add **GitHub Server** configuration
   - Add secret credentials
   - Associate with server

---

## 6️⃣ Verification Steps

### Test IAM Permissions

SSH into your Jenkins server:

```bash
# Test ECR login
aws ecr get-login-password --region eu-west-2

# Test EKS access
aws eks list-clusters --region eu-west-2

# Test STS
aws sts get-caller-identity
```

All commands should work without errors!

### Test GitHub Webhook

1. Go to **GitHub → Repo → Settings → Webhooks**
2. Click your webhook
3. Scroll to **Recent Deliveries**
4. Click a delivery → **Redeliver**
5. Check Jenkins job is triggered

### Test Jenkins Pipeline

Make a small change to your code:

```bash
# In backend/server.js, add a comment
echo "// Test webhook" >> backend/server.js

# Commit and push
git add backend/server.js
git commit -m "Test Jenkins webhook"
git push origin main
```

Check that:
- ✅ GitHub webhook fires
- ✅ Jenkins job triggers automatically
- ✅ Build completes successfully

---

## 📋 Complete IAM Permissions Summary

| Service | Permissions Needed | Why |
|---------|-------------------|-----|
| **ECR** | `GetAuthorizationToken`, `PutImage`, `DescribeImages` | Push Docker images |
| **EKS** | `DescribeCluster`, `ListClusters` | Update kubeconfig for deployments |
| **STS** | `GetCallerIdentity` | Get AWS Account ID for ECR registry URL |
| **S3** | `PutObject`, `GetObject` (optional) | Store build artifacts |

---

## 🔒 Security Best Practices

1. **Use IAM Roles** instead of access keys
2. **Enable webhook secrets** for GitHub
3. **Restrict security groups** to GitHub webhook IPs only
4. **Use HTTPS** for Jenkins (with SSL certificate)
5. **Enable Jenkins authentication** (don't leave it open!)
6. **Regular updates** of Jenkins and plugins
7. **Least privilege** IAM policies (restrict to specific resources)
8. **Enable CloudTrail** to audit AWS API calls

---

## 🚀 Quick Setup Checklist

- [ ] Create IAM policy with ECR + EKS + STS permissions
- [ ] Create IAM role and attach policy
- [ ] Attach IAM role to Jenkins EC2 instance
- [ ] Configure security group to allow port 8080 from 0.0.0.0/0 (or GitHub IPs)
- [ ] Add GitHub PAT to Jenkins credentials
- [ ] Set `AWS_ACCOUNT_ID` in Jenkins global environment variables
- [ ] Install required Jenkins plugins
- [ ] Create Jenkins pipeline jobs
- [ ] Configure GitHub webhook pointing to Jenkins
- [ ] Test webhook delivery
- [ ] Test pipeline build

---

## 🔗 References

- [AWS ECR IAM Permissions](https://docs.aws.amazon.com/AmazonECR/latest/userguide/security_iam_id-based-policy-examples.html)
- [AWS EKS IAM Permissions](https://docs.aws.amazon.com/eks/latest/userguide/security_iam_service-with-iam.html)
- [GitHub Webhook IPs](https://api.github.com/meta)
- [Jenkins GitHub Plugin](https://plugins.jenkins.io/github/)

---

## 💡 Troubleshooting

### Webhook not triggering Jenkins

```bash
# Check Jenkins logs
sudo tail -f /var/log/jenkins/jenkins.log

# Check GitHub webhook deliveries
# GitHub → Settings → Webhooks → Recent Deliveries
```

### ECR permission denied

```bash
# Verify IAM role is attached
aws sts get-caller-identity

# Check ECR permissions
aws ecr describe-repositories --region eu-west-2
```

### EKS access denied

```bash
# Update kubeconfig manually
aws eks update-kubeconfig --region eu-west-2 --name YOUR_CLUSTER_NAME

# Test kubectl
kubectl get nodes
```
