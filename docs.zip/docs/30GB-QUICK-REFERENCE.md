# Jenkins Server 30GB EBS - Quick Reference

## ✅ YES, 30GB is Enough!

**With proper optimization, 30GB is sufficient for your Jenkins CI/CD server.**

---

## 📊 Expected Usage

| Component | Size |
|-----------|------|
| OS + Tools | 10-15 GB |
| Jenkins + Builds | 2-3 GB |
| Docker Storage | 2-4 GB |
| Free Space | 8-13 GB |

---

## 🚀 Quick Setup (Run on Jenkins Server)

```bash
# 1. Copy optimization script to Jenkins server
scp scripts/optimize-jenkins-server.sh ubuntu@<jenkins-ip>:~/

# 2. SSH into Jenkins server
ssh ubuntu@<jenkins-ip>

# 3. Run optimization script
sudo bash optimize-jenkins-server.sh
```

**This script automatically configures:**
- ✅ Docker log limits
- ✅ Daily Docker cleanup (2 AM)
- ✅ Hourly disk monitoring
- ✅ Emergency cleanup tools

---

## 🛡️ Critical Optimizations

### 1. **Automated Cleanup (Already Done by Script)**
Daily cron job cleans:
- Stopped containers
- Dangling images  
- Unused volumes
- Old build cache

### 2. **Jenkins Configuration**

Set "# of executors" to **1**:
- Jenkins → Manage Jenkins → Configure System
- Set "# of executors" = **1**

### 3. **Jenkinsfile Cleanup**

Add to ALL your Jenkinsfiles:

```groovy
pipeline {
    agent any
    
    options {
        buildDiscarder(logRotator(numToKeepStr: '10'))  // Keep last 10 builds
    }
    
    stages {
        // Your stages
    }
    
    post {
        always {
            cleanWs()  // Clean workspace after build
        }
    }
}
```

### 4. **Multi-Stage Dockerfiles**

Use in all 3 services (frontend, backend, admin):

```dockerfile
# Build stage
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build

# Runtime stage (much smaller!)
FROM node:18-alpine
WORKDIR /app
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/node_modules ./node_modules
CMD ["npm", "start"]
```

**Savings:** 500-600 MB per image × 3 = 1.5-2 GB

---

## 📈 Monitoring

```bash
# Check disk usage
df -h /

# Check Docker usage
docker system df

# Check largest directories
du -h --max-depth=1 / 2>/dev/null | sort -rh | head -10

# View cleanup logs
tail -f /var/log/docker-cleanup.log
```

---

## 🚨 Emergency Commands

If disk fills up:

```bash
# Nuclear option (removes EVERYTHING)
sudo /usr/local/bin/emergency-cleanup.sh

# Or manually:
sudo docker system prune -a -f --volumes    # Frees 5-10 GB
sudo rm -rf /var/lib/jenkins/workspace/*    # Frees 2-5 GB
```

---

## ✅ Pre-Flight Checklist

Before running builds:

- [ ] Run optimization script
- [ ] Configure Jenkins executors = 1
- [ ] Add workspace cleanup to Jenkinsfiles
- [ ] Use multi-stage Dockerfiles
- [ ] Test emergency cleanup

---

## 📝 For Assignment Documentation

Include:
- Screenshot of `df -h` showing usage
- Screenshot of `docker system df`
- Cron jobs configuration
- Resource optimization strategies
- Multi-stage Dockerfile examples

---

**Bottom line:** 30GB works perfectly with these optimizations! 🎯
