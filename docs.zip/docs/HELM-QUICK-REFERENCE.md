# Helm Deployment Setup - Quick Reference

## 📁 Directory Structure

```
shopNow-Capstone/
├── helm/
│   ├── backend/
│   │   ├── Chart.yaml          # Chart metadata
│   │   ├── values.yaml         # Default values  
│   │   └── templates/
│   │       ├── deployment.yaml # Backend deployment
│   │       └── service.yaml    # Backend service
│   ├── frontend/
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/
│   │       ├── deployment.yaml
│   │       └── service.yaml
│   └── admin/
│       ├── Chart.yaml
│       ├── values.yaml
│       └── templates/
│           ├── deployment.yaml
│           └── service.yaml
├── jenkins/
│   ├── Jenkinsfile.cicd.backend   # CI/CD with Helm
│   ├── Jenkinsfile.cicd.frontend  # CI/CD with Helm
│   └── Jenkinsfile.cicd.admin     # CI/CD with Helm
└── scripts/
    └── helm-rollback.sh           # Automated rollback
```

---

## 🚀 How It Works

### 1. Jenkins Pipeline Deploys with Helm

```groovy
// Jenkinsfile uses:
helm upgrade --install ${SERVICE_NAME} ./helm/${SERVICE_DIR}/ \
    --namespace shopnow-demo \
    --set image.repository=${ECR_REGISTRY}/${ECR_REPOSITORY} \
    --set image.tag=${IMAGE_TAG} \
    --wait \
    --timeout 5m \
    --atomic  // Auto-rollback on failure!
```

### 2. Image Tags in ECR

Images are tagged as:
- `jatin-capstone:backend-1`, `backend-2`, `backend-3`, ...
- `jatin-capstone:frontend-1`, `frontend-2`, ...
- `jatin-capstone:admin-1`, `admin-2`, ...
- Plus `-latest` tags: `backend-latest`, `frontend-latest`, `admin-latest`

### 3. Helm Tracks Revisions

Each deployment creates a new Helm revision:
```
REVISION  STATUS      CHART         DESCRIPTION
1         superseded  backend-1.0.0 Install complete
2         superseded  backend-1.0.0 Upgrade complete
3         deployed    backend-1.0.0 Upgrade complete
```

---

## 🔄 Rollback Commands

### Quick Rollback (One Command!)

```bash
# Rollback to previous revision
helm rollback backend -n shopnow-demo
helm rollback frontend -n shopnow-demo
helm rollback admin -n shopnow-demo
```

### Rollback to Specific Revision

```bash
# List revisions
helm history backend -n shopnow-demo

# Rollback to specific revision
helm rollback backend 2 -n shopnow-demo
```

### Automated Script

```bash
# Interactive rollback
./scripts/helm-rollback.sh backend

# Rollback to specific revision
./scripts/helm-rollback.sh frontend 2
```

---

## 📊 Common Commands

```bash
# List all releases
helm list -n shopnow-demo

# Get release status
helm status backend -n shopnow-demo

# View revision history
helm history backend -n shopnow-demo

# Get values used in deployment
helm get values backend -n shopnow-demo

# View all resources
helm get manifest backend -n shopnow-demo

# Check which image is running
kubectl get deployment backend -n shopnow-demo \
    -o jsonpath='{.spec.template.spec.containers[0].image}'
```

---

## ✅ Benefits of Helm

- ✅ **Atomic deployments** - All resources deployed together or none
- ✅ **Auto-rollback** - `--atomic` flag rolls back on failure
- ✅ **Versioned releases** - Every deployment is a tracked revision
- ✅ **One-command rollback** - `helm rollback <release>`
- ✅ **Reproducible** - Can redeploy any previous revision exactly
- ✅ **Professional** - Industry standard for Kubernetes deployments

---

## 🔗 Full Documentation

- [ROLLBACK-GUIDE.md](file:///d:/HeroVired/shopNow-Capstone/docs/ROLLBACK-GUIDE.md) - Complete rollback procedures
- [JENKINS-CICD-SETUP.md](file:///d:/HeroVired/shopNow-Capstone/docs/JENKINS-CICD-SETUP.md) - Jenkins configuration guide
