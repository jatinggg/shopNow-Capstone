# Terraform Infrastructure Updates Guide

## 🎯 How Infrastructure Updates Work

When you modify Terraform modules, this guide explains how changes are applied to your actual AWS infrastructure.

---

## 📋 Infrastructure Update Workflow

### 1. Make Changes to Terraform Code

You can modify any Terraform files in `eks-tf/`:

```
eks-tf/
├── main.tf              # Main EKS configuration
├── variables.tf         # Input variables
├── outputs.tf           # Output values
├── provider.tf          # AWS provider & backend
├── demo.tfvars          # Variable values
└── modules/
    ├── vpc/             # VPC module
    └── eks/             # EKS module
```

### 2. Terraform Detects Changes

When you run the pipeline, Terraform:
1. **Reads current state** from S3 (`jatin-s3-shopnow-tfstate`)
2. **Compares** desired state (your code) vs actual state (AWS resources)
3. **Creates a plan** showing what will change

### 3. Review the Plan

Terraform plan shows:
- ✅ **Resources to create** (green `+`)
- 🔄 **Resources to modify** (yellow `~`)
- ❌ **Resources to destroy** (red `-`)
- ➡️ **Resources to recreate** (red `-/+`)

```
Terraform will perform the following actions:

  # aws_eks_node_group.workers will be updated in-place
  ~ resource "aws_eks_node_group" "workers" {
      ~ desired_size = 2 -> 3
      ~ max_size     = 3 -> 5
        # (other attributes unchanged)
    }

Plan: 0 to add, 1 to change, 0 to destroy.
```

### 4. Apply Changes

After manual approval in Jenkins, Terraform applies changes:
- **Creates** new resources
- **Updates** existing resources (in-place when possible)
- **Deletes** removed resources
- **Replaces** resources that can't be updated in-place

---

## 🔄 Common Update Scenarios

### Scenario 1: Change Node Group Size

**What changes**: Node count in EKS cluster

```hcl
# In eks-tf/demo.tfvars
node_desired_size = 3  # Changed from 2
node_max_size     = 5  # Changed from 3
```

**What Terraform does**:
- ✅ **In-place update** - adds new nodes
- No downtime!
- Running pods continue working
- New nodes join cluster

**Impact**:
- 🟢 **Low risk**
- 🟢 **No downtime**
- 🟢 **Reversible**

---

### Scenario 2: Change Kubernetes Version

**What changes**: EKS control plane version

```hcl
# In eks-tf/main.tf or variables
eks_version = "1.28"  # Upgraded from 1.27
```

**What Terraform does**:
- 🔄 **Rolling upgrade** of control plane (AWS managed)
- May trigger node group replacement

**Impact**:
- 🟡 **Medium risk**
- 🟡 **Potential downtime** for workloads
-  **Test in non-prod first!**

**Best Practice**:
1. Upgrade control plane first
2. Then upgrade node groups
3. Test applications after each step

---

### Scenario 3: Change VPC CIDR

**What changes**: VPC network range

```hcl
# In eks-tf/demo.tfvars
vpc_cidr = "10.1.0.0/16"  # Changed from 10.0.0.0/16
```

**What Terraform does**:
- ❌ **DESTROYS entire VPC**
- ❌ **DESTROYS EKS cluster**
- ✅ **CREATES new VPC**
- ✅ **CREATES new EKS cluster**

**Impact**:
- 🔴 **CRITICAL - Complete rebuild!**
- 🔴 **All workloads destroyed**
- 🔴 **Data loss** if not backed up

**⚠️ DANGER**: This is a **destructive change**!

**Safe Approach**:
1. Backup all application data
2. Export Kubernetes resources
3. Create new environment
4. Migrate workloads
5. Delete old environment

---

### Scenario 4: Add New Security Group Rule

**What changes**: Network access rules

```hcl
# In modules/eks/security.tf
resource "aws_security_group_rule" "allow_https" {
  type              = "ingress"
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  cidr_blocks       = ["0.0.0.0/0"]
  security_group_id = aws_security_group.cluster.id
}
```

**What Terraform does**:
- ✅ **Adds new rule** to existing security group
- No disruption

**Impact**:
- 🟢 **Low risk**
- 🟢 **No downtime**
- 🟢 **Instant effect**

---

### Scenario 5: Change Subnet Configuration

**What changes**: Subnet CIDRs or availability zones

```hcl
# In eks-tf/demo.tfvars
public_subnet_cidrs = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
# Added third subnet
```

**What Terraform does**:
- ✅ **Creates** new subnet
- 🔄 **Updates** EKS cluster to use new subnets
- May not delete old subnets if in use

**Impact**:
- 🟡 **Medium risk**
- 🟡 **May require** node replacement
- Review plan carefully!

---

## 🚀 Running Infrastructure Updates

### Option 1: Via Jenkins Pipeline (Recommended)

1. **Push Terraform changes** to Git:
   ```bash
   git add eks-tf/
   git commit -m "Update EKS node count to 3"
   git push origin main
   ```

2. **Trigger Jenkins job**:
   - Go to Jenkins → `ShopNow-EKS-Infrastructure`
   - Click "Build Now"

3. **Pipeline executes**:
   ```
   ✅ Checkout code
   ✅ Terraform init
   ✅ Terraform validate
   ✅ Terraform plan       ← Review changes here!
   ⏸️  Manual approval     ← YOU APPROVE
   ✅ Terraform apply
   ✅ Verify cluster
   ```

4. **Review plan output**:
   - Check what resources will change
   - Look for destructive changes (⚠️ red `-/+`)
   - Click "Approve" only if safe

5. **Monitor apply**:
   - Watch Jenkins logs
   - Check for errors
   - Verify cluster after completion

### Option 2: Manual from CLI

```bash
# 1. Navigate to Terraform directory
cd eks-tf/

# 2. Initialize
terraform init

# 3. Plan (review changes)
terraform plan -var-file="demo.tfvars"

# 4. Apply (if changes look good)
terraform apply -var-file="demo.tfvars"

# 5. Verify
kubectl get nodes
```

---

## 🛡️ Safety Checks Before Applying

### Always Review Plan For:

**1. Resource Destruction** ❌
```
- aws_eks_cluster.main
- aws_eks_node_group.workers
```
**⚠️ This will DELETE resources! Make sure this is intentional.**

**2. Resource Replacement** 🔄
```
-/+ aws_eks_node_group.workers (forces replacement)
```
**⚠️ This will DESTROY and RECREATE. Understand why.**

**3. Multi-Resource Impact** 📊
```
Plan: 5 to add, 1 to change, 5 to destroy.
```
**⚠️ Large changes = higher risk. Review each resource.**

---

## 🔒 Terraform State Management

### Where State is Stored

```
S3 Bucket: jatin-s3-shopnow-tfstate
Key: eks/terraform.tfstate
Region: eu-west-2
Lock: jatin-shopnow-statelock (DynamoDB)
```

### State Locking

**Purpose**: Prevents concurrent modifications

**How it works**:
1. Pipeline starts → Terraform locks state in DynamoDB
2. Another run tries to start → Gets error: "State locked"
3. First run completes → Terraform unlocks state

**If locked**:
```bash
# Force unlock (only if no other runs active!)
cd eks-tf/
terraform force-unlock <LOCK_ID>
```

---

## 📊 Change Impact Matrix

| Change Type | Risk | Downtime | Reversible | Example |
|-------------|------|----------|------------|---------|
| Add resource | 🟢 Low | None | ✅ Yes | Add security group rule |
| Scale nodes up | 🟢 Low | None | ✅ Yes | Increase node count |
| Scale nodes down | 🟡 Medium | Possible | ✅ Yes | Decrease node count |
| Change K8s version | 🟡 Medium | Minimal | ⚠️ Risky | Upgrade 1.27→1.28 |
| Modify VPC | 🔴 Critical | Complete | ❌ No | Change VPC CIDR |
| Delete cluster | 🔴 Critical | Complete | ❌ No | Remove EKS resource |

---

## 🔄 Rollback Strategies

### 1. Terraform Rollback

```bash
# Option A: Revert code changes
git revert <commit-hash>
git push origin main
# Then run pipeline again

# Option B: Restore previous state
cd eks-tf/
terraform state pull > current-state.json
# Copy previous state from S3
aws s3 cp s3://jatin-s3-shopnow-tfstate/eks/terraform.tfstate.backup .
terraform state push terraform.tfstate.backup
```

### 2. AWS Console Rollback

For critical issues:
- Go to AWS EKS console
- Manually revert changes
- Update Terraform code to match
- Run `terraform refresh` to sync state

---

## 📝 Best Practices

### 1. **Always Plan First**
```bash
terraform plan -var-file="demo.tfvars" -out=tfplan
# Review output carefully
terraform apply tfplan
```

### 2. **Test in Non-Prod**
- Create separate `staging.tfvars`
- Test changes there first
- Then apply to production

### 3. **Small Changes**
- Change one thing at a time
- Easier to troubleshoot
- Faster rollback if needed

### 4. **Backup Before Major Changes**
```bash
# Export Kubernetes resources
kubectl get all --all-namespaces -o yaml > k8s-backup.yaml

# Backup Terraform state
aws s3 cp s3://jatin-s3-shopnow-tfstate/eks/terraform.tfstate terraform-state-backup.json
```

### 5. **Document Changes**
```bash
git commit -m "EKS: Increase node count from 2 to 3 for better availability"
```

### 6. **Monitor After Apply**
```bash
# Check cluster health
kubectl get nodes
kubectl get pods --all-namespaces

# Check AWS console
# - EKS cluster status
# - Node group status
# - CloudWatch logs
```

---

## 🚨 Troubleshooting

### Issue: State Lock Error

**Symptom**:
```
Error: Error locking state: Error acquiring the state lock
```

**Solution**:
```bash
# Check DynamoDB for lock
aws dynamodb get-item \
    --table-name jatin-shopnow-statelock \
    --key '{"LockID":{"S":"jatin-s3-shopnow-tfstate/eks/terraform.tfstate"}}'

# If no active run, force unlock
terraform force-unlock <LOCK_ID>
```

### Issue: Resource Already Exists

**Symptom**:
```
Error: resource already exists
```

**Solution**:
```bash
# Import existing resource into state
terraform import aws_eks_cluster.main jatin-shopnow-cluster
```

### Issue: Insufficient Permissions

**Symptom**:
```
Error: AccessDenied
```

**Solution**:
- Check IAM role attached to Jenkins EC2
- Verify role has required permissions (ECR, EKS, VPC, etc.)
- See `docs/JENKINS-IAM-PERMISSIONS.md`

---

## ✅ Pre-Apply Checklist

Before clicking "Approve" in Jenkins:

- [ ] Reviewed Terraform plan output
- [ ] No unexpected resource deletions
- [ ] Understand why resources are being replaced
- [ ] Backed up critical data (if major change)
- [ ] Tested in staging (if available)
- [ ] Team notified (if production)
- [ ] Rollback plan ready
- [ ] Monitoring dashboard open

---

## 📚 Summary

**How updates work**:
1. Modify Terraform code
2. Push to Git / Run pipeline
3. Terraform creates execution plan
4. Review plan carefully
5. Approve if safe
6. Terraform applies changes to AWS
7. Verify cluster health

**Key Principles**:
- 🔍 **Always review** the plan
- 🐢 **Change slowly** - one thing at a time
- 💾 **Backup first** - especially for major changes
- 🧪 **Test** in non-prod
- 📊 **Monitor** after apply

**Remember**: Terraform is infrastructure-as-code. Changes to code = changes to real AWS resources!
