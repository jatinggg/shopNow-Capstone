# Helm Rollback Guide

## 🎯 Helm-Based Deployment Strategy

All CD operations now use **Helm** for atomic deployments, versioned releases, and one-command rollbacks.

### 🏷️ Image Tagging in ECR

Images are tagged in your ECR repository `jatin-capstone`:

**Versioned tags:**
- `backend-1`, `backend-2`, `backend-3`, ...
- `frontend-1`, `frontend-2`, `frontend-3`, ...
- `admin-1`, `admin-2`, `admin-3`, ...

**Latest tags:**
- `backend-latest`, `frontend-latest`, `admin-latest`

---

## 🚀 How Helm Deployment Works

**Jenkins CI/CD Pipeline:**
```bash
# 1. Build & Push Image
docker build -t backend:5 .
docker tag backend:5 <ecr>/jatin-capstone:backend-5
docker tag backend:5 <ecr>/jatin-capstone:backend-latest
docker push <ecr>/jatin-capstone:backend-5
docker push <ecr>/jatin-capstone:backend-latest

# 2. Deploy with Helm (atomic)
helm upgrade --install backend ./helm/backend/ \
    --namespace shopnow-demo \
    --set image.repository=<ecr>/jatin-capstone \
    --set image.tag=backend-5 \
    --wait \
    --timeout 5m \
    --atomic  # Auto-rollback on failure!
```

**Benefits:**
- ✅ **Atomic**: All resources deployed together or none at all
- ✅ **Auto-rollback**: If deployment fails, Helm rolls back automatically
- ✅ **Versioned**: Each deployment is a numbered revision
- ✅ **Reproducible**: Can redeploy any previous revision exactly

---

## 🔄 Rollback Methods

### Method 1: Quick Rollback (One Command!)

```bash
# Rollback to previous revision
helm rollback backend -n shopnow-demo

# Rollback frontend
helm rollback frontend -n shopnow-demo

# Rollback admin
helm rollback admin -n shopnow-demo

# Check rollback status
helm status backend -n shopnow-demo
```

**How it works:**
- Helm keeps revision history automatically
- Rollback restores ALL resources from the previous revision
- Fast and reliable!

---

### Method 2: Rollback to Specific Revision

```bash
# List available revisions
helm history backend -n shopnow-demo

# Example output:
# REVISION  UPDATED                   STATUS      CHART         APP VERSION  DESCRIPTION
# 1         Mon Feb 3 10:00:00 2026   superseded  backend-1.0.0 1.0.0        Install complete
# 2         Mon Feb 3 11:00:00 2026   superseded  backend-1.0.0 1.0.0        Upgrade complete
# 3         Mon Feb 3 12:00:00 2026   deployed    backend-1.0.0 1.0.0        Upgrade complete

# Rollback to specific revision (e.g., revision 1)
helm rollback backend 1 -n shopnow-demo

# Verify rollback
helm status backend -n shopnow-demo
kubectl get pods -n shopnow-demo -l app=backend
```

**Benefits:**
- Roll back to ANY previous revision
- See exactly what changed in each revision
- Helm tracking ensures consistency

---

### Method 3: Automated Rollback Script

Use the provided script for interactive rollback:

```bash
# Rollback backend to revision 2
./scripts/helm-rollback.sh backend 2

# Rollback frontend to revision 5
./scripts/helm-rollback.sh frontend 5

# Rollback admin to previous
./scripts/helm-rollback.sh admin
```

---

## 📊 Helm Commands Reference

### View Deployment Status

```bash
# List all Helm releases
helm list -n shopnow-demo

# Get release status
helm status backend -n shopnow-demo

# View release history
helm history backend -n shopnow-demo

# View values used in deployment
helm get values backend -n shopnow-demo

# View all resources managed by release
helm get manifest backend -n shopnow-demo
```

### Compare Revisions

```bash
# Get manifest for revision 2
helm get manifest backend --revision 2 -n shopnow-demo > rev2.yaml

# Get manifest for revision 3
helm get manifest backend --revision 3 -n shopnow-demo > rev3.yaml

# Compare
diff rev2.yaml rev3.yaml
```

### Check Which Image is Running

```bash
# Method 1: Via kubectl
kubectl get deployment backend -n shopnow-demo \
    -o jsonpath='{.spec.template.spec.containers[0].image}'

# Method 2: Via Helm values
helm get values backend -n shopnow-demo | grep tag

# Method 3: Check pods directly
kubectl get pods -n shopnow-demo -l app=backend \
    -o jsonpath='{.items[0].spec.containers[0].image}'
```

---

## 🛡️ Complete Rollback Process

### 1. Identify the Problem

```bash
# Check current release status
helm status backend -n shopnow-demo

# Check pod status
kubectl get pods -n shopnow-demo -l app=backend

# Check pod logs
kubectl logs -n shopnow-demo -l app=backend --tail=100

# Check recent events
kubectl get events -n shopnow-demo --sort-by='.lastTimestamp' | grep backend
```

### 2. Find the Good Revision

```bash
# View revision history with descriptions
helm history backend -n shopnow-demo

# Example output:
# REVISION  UPDATED                   STATUS      DESCRIPTION
# 1         Feb 6 10:00:00 2026      superseded  Install complete - Build backend-42
# 2         Feb 6 11:00:00 2026      superseded  Upgrade complete - Build backend-43
# 3         Feb 6 12:00:00 2026      deployed    Upgrade complete - Build backend-44 (BROKEN)
```

### 3. Perform Rollback

```bash
# Option 1: Rollback to previous (revision 2)
helm rollback backend -n shopnow-demo

# Option 2: Rollback to specific revision
helm rollback backend 1 -n shopnow-demo

# With cleanup and wait
helm rollback backend --cleanup-on-fail --wait -n shopnow-demo
```

### 4. Verify Rollback

```bash
# Check rollout status
helm status backend -n shopnow-demo

# Verify pods are running
kubectl get pods -n shopnow-demo -l app=backend

# Check image version
kubectl get deployment backend -n shopnow-demo \
    -o jsonpath='{.spec.template.spec.containers[0].image}'

# Wait for pods to be ready
kubectl wait --for=condition=ready pod \
    -l app=backend \
    -n shopnow-demo \
    --timeout=3m
```

### 5. Document and Prevent Re-deployment

- **Fix the code** in Git
- **Pause Jenkins** (temporarily disable webhook)
- **Tag the good revision** in Git for reference
- **Document** what went wrong

---

## 🚨 Emergency Rollback

If production is down:

```bash
# Immediate rollback (fastest - 30 seconds)
helm rollback backend --wait --timeout=2m -n shopnow-demo

# Verify immediately
kubectl get pods -n shopnow-demo -l app=backend

# If still failing, rollback to known good revision
helm rollback backend 1 --force --wait -n shopnow-demo
```

**Emergency flags:**
- `--force`: Force resource updates through delete/recreate if needed
- `--wait`: Wait for all resources to be ready
- `--timeout`: Set timeout for rollback operation
- `--cleanup-on-fail`: Cleanup resources on failed rollback

---

## 📋 Best Practices

### 1. Track Build Numbers in Helm Revisions

Your Jenkins pipeline automatically includes build info, so you can match:
- ECR image: `backend-42`
- Helm values used: `image.tag=backend-42`
- Revision description: Shows which build was deployed

### 2. Keep Revision History

```bash
# Configure retention in your Helm charts
# (Currently keeping default 10 revisions)

# Or manually limit during install/upgrade
helm upgrade --install backend ./helm/backend/ \
    --history-max 20 \
    -n shopnow-demo
```

### 3. Test Before Rolling Back

```bash
# Create a test namespace
kubectl create namespace shopnow-test

# Deploy the old revision there first
helm install backend-test ./helm/backend/ \
    --namespace shopnow-test \
    --set image.repository=<ecr>/jatin-capstone \
    --set image.tag=backend-42

# Test it
curl http://backend-test-service.shopnow-test:5000/health

# If good, rollback production
helm rollback backend -n shopnow-demo
```

### 4. Automatic Rollback on Failure

Your Jenkins pipeline uses `--atomic` flag:
```groovy
helm upgrade --install ${SERVICE_NAME} ./helm/${SERVICE_DIR}/ \
    --atomic  # This automatically rolls back on failure!
```

**What `--atomic` does:**
- If deployment fails, Helm **automatically rolls back** to previous revision
- No manual intervention needed!
- Keeps production stable

---

## 🔍 Advanced Helm Features

### Dry Run Before Deploy

```bash
# Preview what would be deployed
helm upgrade --install backend ./helm/backend/ \
    --dry-run --debug \
    --set image.tag=backend-50 \
    -n shopnow-demo
```

### Diff Between Current and New

```bash
# Install helm-diff plugin
helm plugin install https://github.com/databus23/helm-diff

# See what would change
helm diff upgrade backend ./helm/backend/ \
    --set image.tag=backend-50 \
    -n shopnow-demo
```

### Helm Hooks for Advanced Workflows

You can add pre/post deployment hooks in your Helm charts:

```yaml
# In helm/backend/templates/pre-deploy-job.yaml
apiVersion: batch/v1
kind: Job
metadata:
  name: backend-db-migration
  annotations:
    "helm.sh/hook": pre-upgrade
    "helm.sh/hook-weight": "-5"
spec:
  template:
    spec:
      containers:
      - name: migration
        image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
        command: ["npm", "run", "migrate"]
      restartPolicy: Never
```

---

## ✅ Summary

**Your Helm Deployment Setup:**
- ✅ All deployments via Helm
- ✅ Atomic deployments (auto-rollback on failure)
- ✅ Versioned releases (can track history)
- ✅ One-command rollback
- ✅ Image tags include service name + build number

**Rollback Commands:**
```bash
# Quick rollback
helm rollback <service> -n shopnow-demo

# Specific revision
helm rollback <service> <revision> -n shopnow-demo

# View history
helm history <service> -n shopnow-demo

# Check status
helm status <service> -n shopnow-demo
```

**This is the professional way to manage Kubernetes deployments!** 🚀
