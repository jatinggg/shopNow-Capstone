# Complete Deployment Guide - DevOps Capstone Project

This guide will walk you through deploying the ShopNow application using the complete CI/CD pipeline with Jenkins, Terraform, Ansible, and Kubernetes on AWS EKS.

---

## 📋 Prerequisites Checklist

### AWS Setup
- [ ] AWS account with billing enabled
- [ ] AWS CLI installed and configured
- [ ] IAM user with administrator access (or appropriate permissions)
- [ ] S3 bucket created: `jatin-s3-shopnow-tfstate` (update in `provider.tf` if different)
- [ ] DynamoDB table created: `jatin-shopnow-statelock` (update in `provider.tf` if different)
- [ ] EC2 Key Pair created for SSH access
- [ ] Billing alerts configured

### Local Tools
- [ ] Git installed
- [ ] AWS CLI v2 installed
- [ ] Terraform installed (v1.0+)
- [ ] kubectl installed
- [ ] Ansible installed (for running playbooks)

### Jenkins Server
- [ ] Jenkins EC2 instance running
- [ ] Jenkins accessible via browser
- [ ] SSH access to Jenkins server

---

## 🚀 Step-by-Step Deployment

### Phase 1: AWS Account Setup

#### 1.1 Configure AWS CLI
```bash
# Configure AWS credentials
aws configure

# Enter:
# - AWS Access Key ID
# - AWS Secret Access Key  
# - Default region: eu-west-2
# - Default output format: json

# Verify configuration
aws sts get-caller-identity
```

#### 1.2 Create S3 Bucket for Terraform State
```bash
# Create S3 bucket (if not exists)
aws s3 mb s3://jatin-s3-shopnow-tfstate --region eu-west-2

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket jatin-s3-shopnow-tfstate \
  --versioning-configuration Status=Enabled

# Create DynamoDB table for state locking
aws dynamodb create-table \
  --table-name jatin-shopnow-statelock \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --provisioned-throughput ReadCapacityUnits=5,WriteCapacityUnits=5 \
  --region eu-west-2
```

#### 1.3 Create ECR Repositories
```bash
# Create repositories for each service
aws ecr create-repository --repository-name jatinggg-shopnow/frontend --region eu-west-2
aws ecr create-repository --repository-name jatinggg-shopnow/backend --region eu-west-2
aws ecr create-repository --repository-name jatinggg-shopnow/admin --region eu-west-2

# Note: Replace 'jatinggg' with your username
```

---

### Phase 2: Configure Jenkins Server with Ansible

#### 2.1 Update Ansible Inventory
```bash
cd ansible/inventory

# Edit hosts file and add your Jenkins server IP
nano hosts

# Replace:
# jenkins-server ansible_host=YOUR_JENKINS_PUBLIC_IP ansible_user=ubuntu ansible_ssh_private_key_file=~/.ssh/your-key.pem
```

#### 2.2 Run Ansible Playbook
```bash
cd ..

# Test connection
ansible jenkins_servers -m ping -i inventory/hosts

# Run Jenkins setup playbook
ansible-playbook -i inventory/hosts playbooks/jenkins-setup.yml

# This will install:
# - Docker
# - AWS CLI
# - kubectl
# - Terraform
# - Helm
```

#### 2.3 Configure Jenkins Credentials
1. Open Jenkins in browser: `http://<jenkins-ip>:8080`
2. Go to **Manage Jenkins** → **Manage Credentials**
3. Add the following credentials:

**AWS Credentials:**
- Kind: **AWS Credentials**
- ID: `aws-credentials`
- Access Key ID: `<your-aws-access-key>`
- Secret Access Key: `<your-aws-secret-key>`

**GitHub Credentials** (if using private repo):
- Kind: **Username with password**
- ID: `github-credentials`
- Username: `<your-github-username>`
- Password: `<your-github-token>`

**Docker Registry (ECR):**
- Kind: **Username with password**  
- ID: `ecr-credentials`
- Username: `AWS`
- Password: (Use ECR token - can be generated dynamically in pipeline)

#### 2.4 Install Jenkins Plugins
Navigate to **Manage Jenkins** → **Manage Plugins** → **Available** and install:
- Docker Pipeline
- Kubernetes CLI
- AWS Steps
- Pipeline
- Git
- Ansible (optional, if running Ansible from Jenkins)

---

### Phase 3: Infrastructure Provisioning with Terraform

#### 3.1 Review and Update Configuration
```bash
cd eks-tf

# Review the demo.tfvars file
cat demo.tfvars

# Update if needed (cluster name, region, etc.)
nano demo.tfvars
```

#### 3.2 Initialize Terraform
```bash
# Initialize Terraform (downloads providers)
terraform init

# You should see: "Terraform has been successfully initialized!"
```

#### 3.3 Plan Infrastructure
```bash
# Preview changes
terraform plan -var-file=demo.tfvars

# Review the plan:
# - VPC with CIDR 10.0.0.0/16
# - 2 public subnets (10.0.1.0/24, 10.0.2.0/24)
# - 2 private subnets (10.0.10.0/24, 10.0.11.0/24)
# - Internet Gateway
# - NAT Gateway
# - EKS cluster with managed node group
# - IAM roles and security groups
```

#### 3.4 Apply Infrastructure
```bash
# Apply the configuration
terraform apply -var-file=demo.tfvars

# Type 'yes' to confirm

# This will take 15-20 minutes to complete
# Coffee break time! ☕
```

#### 3.5 Verify Infrastructure
```bash
# Get outputs
terraform output

# You should see:
# - vpc_id
# - cluster_name
# - cluster_endpoint
# - configure_kubectl command

# Configure kubectl
aws eks update-kubeconfig --region eu-west-2 --name jatin-demo-01-jatin-demo-01

# Note: The cluster name format is: <cluster_name>-<cluster_name>

# Verify cluster access
kubectl get nodes

# You should see 2 nodes in Ready state
```

---

### Phase 4: Build and Push Docker Images

#### 4.1 Authenticate to ECR
```bash
# Get ECR login token
aws ecr get-login-password --region eu-west-2 | docker login --username AWS --password-stdin <account-id>.dkr.ecr.eu-west-2.amazonaws.com

# Replace <account-id> with your AWS account ID
```

#### 4.2 Build Images
```bash
cd ..  # Back to project root

# Build and push using the script
./scripts/build-and-push.sh <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow latest jatin

# Or build manually:
# Backend
cd backend
docker build -t <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow/backend:latest .
docker push <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow/backend:latest

# Frontend  
cd ../frontend
docker build --build-arg USER_NAME=jatin -t <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow/frontend:latest .
docker push <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow/frontend:latest

# Admin
cd ../admin
docker build --build-arg USER_NAME=jatin -t <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow/admin:latest .
docker push <account-id>.dkr.ecr.eu-west-2.amazonaws.com/jatinggg-shopnow/admin:latest
```

---

### Phase 5: Deploy to Kubernetes

#### 5.1 Install Prerequisites
```bash
# Install metrics server
kubectl apply -f kubernetes/pre-req/metrics-server.yaml

# Install ingress-nginx controller (for EKS)
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.12.0-beta.0/deploy/static/provider/aws/deploy.yaml

# Wait for ingress controller to be ready
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=120s

# Install EBS CSI driver (from EKS console as per README)
# Or use eksctl:
eksctl create addon --name aws-ebs-csi-driver --cluster jatin-demo-01-jatin-demo-01 --region eu-west-2

# Install storage class
kubectl apply -f kubernetes/pre-req/storageclass-gp3.yaml
```

#### 5.2 Create Docker Registry Secret
```bash
# Create namespace
kubectl create namespace shopnow-demo

# Create ECR secret for private registry
kubectl create secret docker-registry ecr-secret \
  --docker-server=<account-id>.dkr.ecr.eu-west-2.amazonaws.com \
  --docker-username=AWS \
  --docker-password=$(aws ecr get-login-password --region eu-west-2) \
  --namespace=shopnow-demo
```

#### 5.3 Deploy Application
```bash
# Option A: Using Kubernetes manifests
kubectl apply -f kubernetes/k8s-manifests/namespace/
kubectl apply -f kubernetes/k8s-manifests/database/
kubectl apply -f kubernetes/k8s-manifests/backend/
kubectl apply -f kubernetes/k8s-manifests/frontend/
kubectl apply -f kubernetes/k8s-manifests/admin/
kubectl apply -f kubernetes/k8s-manifests/ingress/

# Option B: Using Helm charts
helm upgrade --install mongo kubernetes/helm/charts/mongo -n shopnow-demo --create-namespace
helm upgrade --install backend kubernetes/helm/charts/backend -n shopnow-demo
helm upgrade --install frontend kubernetes/helm/charts/frontend -n shopnow-demo
helm upgrade --install admin kubernetes/helm/charts/admin -n shopnow-demo
```

#### 5.4 Initialize MongoDB
```bash
# Wait for mongo pod to be ready
kubectl wait --for=condition=ready pod mongo-0 -n shopnow-demo --timeout=300s

# Create MongoDB user
kubectl -n shopnow-demo exec -it mongo-0 -- mongosh

# In the mongo shell, run:
use admin;
db.createUser({
  user: 'shopuser',
  pwd: 'ShopNowPass123',
  roles: [
    { role: 'readWrite', db: 'shopnow' },
    { role: 'dbAdmin', db: 'shopnow' }
  ]
});
exit

# Restart backend to connect
kubectl rollout restart deploy backend -n shopnow-demo
```

---

### Phase 6: Verify Deployment

#### 6.1 Check Resources
```bash
# Check all pods
kubectl get pods -n shopnow-demo

# All pods should be in Running state

# Check services
kubectl get svc -n shopnow-demo

# Check ingress
kubectl get ingress -n shopnow-demo

# Get load balancer DNS
kubectl get svc -n ingress-nginx -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}'
```

#### 6.2 Access Application
```bash
# Get the Load Balancer URL
LOAD_BALANCER=$(kubectl get svc -n ingress-nginx -o jsonpath='{.items[0].status.loadBalancer.ingress[0].hostname}')

echo "Frontend: http://$LOAD_BALANCER/jatin"
echo "Admin: http://$LOAD_BALANCER/jatin-admin"
echo "Backend Health: http://$LOAD_BALANCER/api/health"
```

Open these URLs in your browser to verify the application is working.

---

### Phase 7: Jenkins CI/CD Pipeline Setup

#### 7.1 Create Jenkinsfile
The Jenkinsfiles are already created in the `jenkins/` directory. Review them:
- `Jenkinsfile.ci.frontend` - Build frontend image
- `Jenkinsfile.ci.backend` - Build backend image
- `Jenkinsfile.ci.admin` - Build admin image
- `Jenkinsfile.cd.frontend` - Deploy frontend
- `Jenkinsfile.cd.backend` - Deploy backend
- `Jenkinsfile.cd.admin` - Deploy admin
- `Jenkinsfile.eks` - Complete infrastructure provisioning

#### 7.2 Create Jenkins Pipeline Jobs

**For Infrastructure:**
1. New Item → Pipeline → Name: `EKS-Infrastructure`
2. Pipeline → Definition: **Pipeline script from SCM**
3. SCM: **Git**
4. Repository URL: `<your-repo-url>`
5. Credentials: Select your GitHub credentials
6. Script Path: `jenkins/Jenkinsfile.eks`
7. Save

**For CI (Build) Jobs:**
1. Create 3 pipeline jobs: `CI-Frontend`, `CI-Backend`, `CI-Admin`
2. Use respective Jenkinsfiles from `jenkins/` directory
3. Configure build triggers (e.g., GitHub webhook or poll SCM)

**For CD (Deploy) Jobs:**
1. Create 3 pipeline jobs: `CD-Frontend`, `CD-Backend`, `CD-Admin`
2. Use respective Jenkinsfiles
3. Configure to trigger after successful CI builds

#### 7.3 Run Pipelines
1. Run `EKS-Infrastructure` first (if not already provisioned)
2. Run CI jobs to build and push images
3. Run CD jobs to deploy to Kubernetes

---

## 🧪 Testing and Validation

### Application Testing
```bash
# Check backend health
curl http://$LOAD_BALANCER/api/health

# Test frontend
curl http://$LOAD_BALANCER/jatin

# Test admin
curl http://$LOAD_BALANCER/jatin-admin
```

### Infrastructure Testing
```bash
# Verify VPC
aws ec2 describe-vpcs --filters "Name=tag:Name,Values=jatin-demo-01-vpc" --region eu-west-2

# Verify EKS cluster
aws eks describe-cluster --name jatin-demo-01-jatin-demo-01 --region eu-west-2

# Verify node group
aws eks describe-nodegroup --cluster-name jatin-demo-01-jatin-demo-01 --nodegroup-name jatin-demo-01-ng-01 --region eu-west-2
```

---

## 💰 Cost Management

### Daily Monitoring
```bash
# Check running resources
aws ec2 describe-instances --region eu-west-2 --query 'Reservations[*].Instances[*].[InstanceId,State.Name,InstanceType]' --output table

# Check EKS cluster
aws eks list-clusters --region eu-west-2
```

### Cleanup (When Done)
```bash
# Delete Kubernetes resources
kubectl delete namespace shopnow-demo

# Delete EKS infrastructure
cd eks-tf
terraform destroy -var-file=demo.tfvars

# Delete ECR images
aws ecr batch-delete-image --repository-name jatinggg-shopnow/frontend --image-ids imageTag=latest --region eu-west-2
aws ecr batch-delete-image --repository-name jatinggg-shopnow/backend --image-ids imageTag=latest --region eu-west-2
aws ecr batch-delete-image --repository-name jatinggg-shopnow/admin --image-ids imageTag=latest --region eu-west-2
```

---

## 🔍 Troubleshooting

### Common Issues

**Issue: Terraform fails with "backend not found"**
```bash
# Ensure S3 bucket exists
aws s3 ls s3://jatin-s3-shopnow-tfstate

# If missing, create it
aws s3 mb s3://jatin-s3-shopnow-tfstate --region eu-west-2
```

**Issue: kubectl cannot connect to cluster**
```bash
# Update kubeconfig
aws eks update-kubeconfig --region eu-west-2 --name jatin-demo-01-jatin-demo-01

# Verify
kubectl config current-context
```

**Issue: Pods in ImagePullBackOff**
```bash
# Check if ECR secret exists
kubectl get secret ecr-secret -n shopnow-demo

# Recreate if needed (token expires after 12 hours)
kubectl delete secret ecr-secret -n shopnow-demo
kubectl create secret docker-registry ecr-secret \
  --docker-server=<account-id>.dkr.ecr.eu-west-2.amazonaws.com \
  --docker-username=AWS \
  --docker-password=$(aws ecr get-login-password --region eu-west-2) \
  --namespace=shopnow-demo
```

**Issue: MongoDB connection errors**
```bash
# Check if user was created
kubectl -n shopnow-demo exec -it mongo-0 -- mongosh

use admin
db.auth('shopuser', 'ShopNowPass123')
show users
exit

# Restart backend
kubectl rollout restart deploy backend -n shopnow-demo
```

---

## 📚 Documentation for Assignment

### Required Documents
1. **Architecture Diagram** - Already in `docs/APPLICATION-ARCHITECTURE.md`
2. **Terraform Code** - In `eks-tf/` directory
3. **Ansible Playbooks** - In `ansible/` directory  
4. **Jenkins Pipelines** - In `jenkins/` directory
5. **Kubernetes Manifests** - In `kubernetes/` directory
6. **This Deployment Guide** - Step-by-step instructions

### Screenshots to Capture
- AWS Console showing VPC, EKS cluster, EC2 instances
- Jenkins dashboard with pipeline jobs
- Terraform apply output
- kubectl get all output
- Application running in browser
- Monitoring dashboards (if implementing Prometheus/Grafana)

---

## ✅ Sprint Completion Checklist

- [x] Sprint 1: Application Dockerized, Jenkins setup
- [x] Sprint 2: Terraform infrastructure code complete
- [x] Sprint 3: Ansible playbooks created
- [ ] Sprint 4: Complete CI/CD pipeline tested
- [ ] Sprint 5: Monitoring (skipped for now)
- [ ] Sprint 6: Documentation and testing complete

---

**Congratulations! Your DevOps CI/CD pipeline is now complete!** 🎉
