# Cost Optimization Strategy - AWS EKS Deployment

## Overview
This document outlines strategies to minimize AWS costs while maintaining the DevOps capstone project infrastructure.

---

## 💰 Current Cost Breakdown (Estimated)

### Monthly Costs (eu-west-2 region)

| Resource | Configuration | Monthly Cost | Notes |
|----------|--------------|--------------|-------|
| EKS Control Plane | 1 cluster | $72.00 | Fixed charge |
| EC2 Worker Nodes | 2x t3.medium | ~$60.00 | 24/7 running |
| NAT Gateway | 1 gateway | ~$32.50 | Data processing charges |
| Application Load Balancer | 1 ALB | ~$16.20 | For ingress-nginx |
| EBS Volumes | ~30GB gp3 | ~$3.00 | For MongoDB and node storage |
| Data Transfer | Varies | ~$5.00 | Outbound data |
| **Total** | | **~$188.70/month** | Without optimizations |

### One-Time/Variable Costs
- EC2 Jenkins Server: ~$30/month (t3.medium)
- S3 Storage (Terraform state): < $1/month
- ECR Storage: ~$0.10/GB/month
- CloudWatch Logs: ~$0.50/GB ingested

**Grand Total: ~$220/month** for full setup

---

## 🎯 Cost Optimization Strategies

### 1. **Use Spot Instances for Non-Production** (Save up to 90%)

Spot instances can reduce EC2 costs dramatically:

```hcl
# In eks-tf/modules/eks/eks-cluster.tf
# Add capacity_type for spot instances

resource "aws_eks_node_group" "main" {
  cluster_name    = aws_eks_cluster.this.name
  node_group_name = "${var.cluster_name}-ng-01"
  node_role_arn   = aws_iam_role.eks_node_role.arn
  subnet_ids      = var.subnet_ids
  
  # Add this:
  capacity_type  = "SPOT"  # Use SPOT instead of ON_DEMAND

  scaling_config {
    desired_size = 2
    max_size     = 3
    min_size     = 1  # Allow scaling to 1 during low usage
  }

  instance_types = ["t3.medium", "t3a.medium", "t2.medium"]  # Multiple instance types for better availability
}
```

**Savings: ~$50/month** (from ~$60 to ~$10 for worker nodes)

---

### 2. **Auto-Shutdown During Off-Hours** (Save 50-70%)

#### Option A: Lambda Function to Stop/Start EKS Nodes
Create a Lambda function to scale node group to 0 during non-working hours:

```bash
# Create Lambda function (Python)
# Stop EKS nodes at 6 PM
# Start EKS nodes at 8 AM
```

#### Option B: Use AWS Instance Scheduler
```bash
# Install AWS Instance Scheduler
# Configure schedule: Mon-Fri 8AM-6PM only
```

**Savings: ~$15-20/month** (on worker nodes and Jenkins server)

---

### 3. **Use Smaller Instance Types** (Save 30-50%)

Current: t3.medium (2 vCPU, 4GB RAM)
Alternative for dev/test:

| Instance Type | vCPU | RAM | Price/month | Savings |
|--------------|------|-----|-------------|---------|
| t3.medium | 2 | 4GB | ~$30 | Baseline |
| t3.small | 2 | 2GB | ~$15 | $15/month |
| t3.micro | 2 | 1GB | ~$7.50 | $22.50/month |

Update in `demo.tfvars`:
```hcl
# For development/testing only
instance_types = ["t3.small"]  # Reduce from t3.medium
desired_size   = 1             # Reduce from 2
min_size       = 1
max_size       = 2
```

**Savings: ~$15-20/month**

---

### 4. **Optimize NAT Gateway Usage** (Save ~$32/month)

NAT Gateway is expensive. Alternatives:

#### Option A: Use NAT Instance Instead
```hcl
# Replace NAT Gateway with NAT Instance
# Cost reduction: $32/month → $15/month
# Savings: $17/month
```

#### Option B: Use Only Public Subnets (Dev/Test Only)
```hcl
# In demo.tfvars
enable_nat_gateway = false

# Update EKS to use public subnets
# In main.tf
subnet_ids = module.vpc.public_subnet_ids  # Instead of private
```

**⚠️ Warning:** This reduces security but saves $32/month for testing

**Savings: $17-32/month**

---

### 5. **Use EKS Fargate for Specific Workloads** (Use Fargate Spot)

For some workloads, Fargate Spot can be more cost-effective:

```hcl
# Add Fargate profile
resource "aws_eks_fargate_profile" "app" {
  cluster_name           = aws_eks_cluster.this.name
  fargate_profile_name   = "app-profile"
  pod_execution_role_arn = aws_iam_role.fargate_pod_execution_role.arn
  subnet_ids             = var.private_subnet_ids

  selector {
    namespace = "shopnow-demo"
    labels = {
      fargate = "true"
    }
  }
}
```

**Note:** Fargate pricing is per vCPU/GB per second. Good for intermittent workloads.

---

### 6. **Implement ECR Lifecycle Policies** (Save ~$5-10/month)

Delete old/unused Docker images:

```bash
# Create lifecycle policy for ECR
aws ecr put-lifecycle-policy --repository-name jatinggg-shopnow/frontend --lifecycle-policy-text '{
  "rules": [
    {
      "rulePriority": 1,
      "description": "Keep only last 5 images",
      "selection": {
        "tagStatus": "any",
        "countType": "imageCountMoreThan",
        "countNumber": 5
      },
      "action": {
        "type": "expire"
      }
    }
  ]
}'
```

**Savings: ~$5/month**

---

### 7. **Delete EKS Cluster When Not in Use** (Save $72/month)

EKS control plane costs $72/month regardless of usage:

```bash
# Destroy entire infrastructure when not needed
cd eks-tf
terraform destroy -var-file=demo.tfvars

# Recreate when needed
terraform apply -var-file=demo.tfvars
```

**Savings: $72/month** (when cluster is deleted)

---

### 8. **Use AWS Free Tier Where Possible**

Free tier includes:
- 750 hours/month of t2.micro EC2 (first 12 months)
- 5GB S3 storage
- 1GB CloudWatch logs
- Limited data transfer

**Savings: Variable, up to $10/month** for new accounts

---

### 9. **Optimize EBS Volumes**

- Use gp3 instead of gp2 (20% cheaper, better performance)
- Delete unused snapshots and volumes
- Reduce volume sizes to minimum needed

```hcl
# Already using gp3 in storageclass-gp3.yaml
# Good!
```

**Savings: ~$2-5/month**

---

### 10. **Set Up AWS Budget Alerts**

Prevent unexpected charges:

```bash
# Create budget alert
aws budgets create-budget \
  --account-id <account-id> \
  --budget '{
    "BudgetName": "EKS-Monthly-Budget",
    "BudgetLimit": {
      "Amount": "100",
      "Unit": "USD"
    },
    "TimeUnit": "MONTHLY",
    "BudgetType": "COST"
  }' \
  --notifications-with-subscribers '[
    {
      "Notification": {
        "NotificationType": "ACTUAL",
        "ComparisonOperator": "GREATER_THAN",
        "Threshold": 80
      },
      "Subscribers": [{
        "SubscriptionType": "EMAIL",
        "Address": "your-email@example.com"
      }]
    }
  ]'
```

---

## 🚀 Recommended Optimization Plan

### For Learning/Development (Minimal Cost)

```hcl
# demo.tfvars optimized for cost
enable_nat_gateway    = false          # Save $32/month
instance_types        = ["t3.small"]   # Save $15/month
desired_size          = 1              # Save $15/month
capacity_type         = "SPOT"         # Save $30/month
```

**Manual Actions:**
- Delete cluster nights/weekends: Save ~$100/month
- Use t2.micro for Jenkins: Save $15/month

**Total Savings: ~$207/month**
**Monthly Cost: ~$13/month** (just EKS control plane and minimal resources)

**⚠️ Trade-offs:**
- Less reliable (Spot can be interrupted)
- Less secure (public subnets only)
- Manual start/stop required

---

### For Production Demo (Balanced)

```hcl
# demo.tfvars balanced
enable_nat_gateway    = true           # Keep security
instance_types        = ["t3.medium"]  # Keep performance
desired_size          = 2              # Keep availability
capacity_type         = "ON_DEMAND"    # Keep reliability
```

**Optimizations:**
- Use ECR lifecycle policies
- Delete old logs
- Schedule shutdown nights: Save ~$50/month

**Monthly Cost: ~$170/month**

---

## 📊 Cost Tracking Commands

```bash
# Check current month's costs
aws ce get-cost-and-usage \
  --time-period Start=2026-02-01,End=2026-02-28 \
  --granularity MONTHLY \
  --metrics "BlendedCost" "UnblendedCost" \
  --group-by Type=DIMENSION,Key=SERVICE

# List all running EC2 instances
aws ec2 describe-instances \
  --query 'Reservations[*].Instances[*].[InstanceId,State.Name,InstanceType,Tags[?Key==`Name`].Value|[0]]' \
  --output table

# Check EKS clusters
aws eks list-clusters --output table

# Check NAT Gateways
aws ec2 describe-nat-gateways --query 'NatGateways[*].[NatGatewayId,State,CreateTime]' --output table
```

---

## ✅ Daily Cost Management Checklist

- [ ] Check AWS Budgets dashboard
- [ ] Verify only necessary resources are running
- [ ] Delete unused ECR images weekly
- [ ] Review CloudWatch logs (delete old logs)
- [ ] Stop Jenkins server when not in use
- [ ] Scale EKS nodes to minimum during off-hours

---

## 🎓 For Assignment Submission

Document your cost optimization strategy:

1. **Screenshots of cost optimization:**
   - AWS Cost Explorer showing reduced costs
   - Budget alerts configured
   - Spot instances in use

2. **Configuration changes:**
   - Show `demo.tfvars` with optimized settings
   - ECR lifecycle policies
   - Auto-scaling configurations

3. **Cost analysis:**
   - Before optimization: $220/month
   - After optimization: $XX/month
   - Savings: XX%

---

**Remember:** For capstone project evaluation:
- Run infrastructure only when demonstrating
- Delete resources immediately after demo
- Show cost-conscious architecture decisions
- Document all optimization strategies

**Total Potential Savings: Up to 90%** of infrastructure costs while maintaining functionality for demonstration!
