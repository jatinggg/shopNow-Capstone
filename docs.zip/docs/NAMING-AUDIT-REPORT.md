# Resource Naming Audit Report

## 🔍 Issues Found

### 1. **Port Naming Inconsistency** ❌

**Issue**: Backend deployment uses `containerPort` without a name, while the service uses `name: http`.

**Location**: 
- `helm/backend/templates/deployment.yaml` line 26
- `helm/frontend/templates/deployment.yaml` line 26
- `helm/admin/templates/deployment.yaml` line 26

**Standard**: Container ports should have names for clarity and service port mapping.

**Fix Required**: Add `name: http` to container ports.

---

### 2. **Missing Additional Labels** ⚠️

**Issue**: Resources only have `app` label. Missing recommended Kubernetes labels.

**Standard Kubernetes Labels** (Recommended):
```yaml
labels:
  app.kubernetes.io/name: backend
  app.kubernetes.io/instance: backend-release
  app.kubernetes.io/version: "1.0.0"
  app.kubernetes.io/component: api
  app.kubernetes.io/part-of: shopnow
  app.kubernetes.io/managed-by: Helm
```

**Current**:
```yaml
labels:
  app: backend
```

**Recommendation**: Add standard labels for better resource management and filtering.

---

### 3. **Service Naming Convention** ✅ (Acceptable but could be standardized)

**Current Naming**:
- Deployment: `backend`
- Service: `backend-service`

**Options**:
1. **Keep current** (Standard pattern - deployment name + `-service`)
2. **Change to**: Both use just `backend` (simpler but less clear)
3. **Change to**: Both use hyphenated names `backend-api`, `backend-api-service`

**Recommendation**: Keep current naming - it's a common pattern.

---

### 4. **Container Names Match Deployment Names** ✅

**Current**: Container name = Deployment name = Service selector
- ✅ `backend` deployment → `backend` container → `app: backend` selector
- ✅ `frontend` deployment → `frontend` container → `app: frontend` selector
- ✅ `admin` deployment → `admin` container → `app: admin` selector

**Status**: Consistent and correct!

---

### 5. **Helm Release Names vs Resource Names** ⚠️

**Issue**: Helm release name (from Jenkins) = service name = deployment name

**Jenkins sets**:
```bash
helm upgrade --install backend ./helm/backend/
                      ^^^^^^ Release name
```

**Helm creates**:
- Release: `backend`
- Deployment: `backend` (from template)
- Service: `backend-service` (from template)

**Potential Issue**: If you want to deploy multiple instances (e.g., staging, production), release names will conflict.

**Better Approach**:
```yaml
# Use Helm release name in templates
metadata:
  name: {{ .Release.Name }}  # Instead of hardcoded "backend"
  labels:
    app: {{ .Chart.Name }}
    release: {{ .Release.Name }}
```

---

## ✅ What's Already Correct

1. **Lowercase naming** - All resource names use lowercase ✅
2. **No special characters** - Only hyphens used ✅
3. **Consistent selectors** - Labels match across deployment/service ✅
4. **Standard resource types** - Using Deployment (not ReplicationController) ✅
5. **Port protocols** - Correctly specified as TCP ✅
6. **Image pull policy** - Using IfNotPresent ✅

---

## 🔧 Recommended Fixes

### Priority 1: Add Named Ports to Deployments

**Why**: Better service-to-port mapping, easier debugging

**Change**: Add `name: http` to container ports

### Priority 2: Add Standard Kubernetes Labels

**Why**: Better resource filtering, metadata, and GitOps integration

**Change**: Add `app.kubernetes.io/*` labels to all resources

### Priority 3: Use Helm Variables for Resource Names

**Why**: Enable multiple deployments (staging, prod) without conflicts

**Change**: Use `{{ .Release.Name }}` instead of hardcoded names

---

## 📋 Implementation Plan

### Option A: Minimal Changes (Safe)
✅ Keep current naming
✅ Add named ports to containers
✅ Add standard labels

### Option B: Full Standardization (Recommended)
✅ Add named ports
✅ Add standard labels
✅ Use Helm templating for resource names
✅ Add environment-specific suffixes support

---

## 🎯 Standardized Template Example

### Deployment (Recommended Updates)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "backend.fullname" . }}
  labels:
    {{- include "backend.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "backend.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      labels:
        {{- include "backend.selectorLabels" . | nindent 8 }}
    spec:
      containers:
      - name: {{ .Chart.Name }}
        image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
        ports:
        - name: http
          containerPort: {{ .Values.deployment.containerPort }}
          protocol: TCP
```

### _helpers.tpl (Add this file)

```yaml
{{/*
Expand the name of the chart.
*/}}
{{- define "backend.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "backend.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "backend.labels" -}}
app.kubernetes.io/name: {{ include "backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ .Chart.Name }}-{{ .Chart.Version }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
```

---

## 🚦 Decision Required

**Question for User**: Which approach do you prefer?

### Option A: Minimal (Quick Fix)
- Add named ports
- Keep current names
- No breaking changes
- **Time**: 5 minutes

### Option B: Full Standards (Best Practice)
- Add named ports
- Add standard labels
- Add Helm helpers
- Use templated names
- **Time**: 20 minutes

**Recommendation**: **Option B** for production-ready setup
