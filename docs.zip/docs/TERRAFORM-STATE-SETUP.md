# Terraform State Configuration - Using Existing S3 Bucket

## 🎯 Recommended Change

Since you already have:
- S3 bucket: `jatin-s3-shopnow-tfstate`
- DynamoDB table: `jatin-shopnow-statelock`

You should **change the state file key** to avoid overwriting existing state files.

---

## ✅ OPTION 1: Use Different State Key (RECOMMENDED)

### Current Configuration
```hcl
# eks-tf/provider.tf (lines 21-27)
backend "s3" {
  bucket         = "jatin-s3-shopnow-tfstate"
  key            = "terraform/terraform.tfstate"  # ⚠️ Might conflict with existing files
  region         = "eu-west-2"
  dynamodb_table = "jatin-shopnow-statelock"
  encrypt        = true
}
```

### Recommended Configuration
```hcl
# eks-tf/provider.tf (lines 21-27)
backend "s3" {
  bucket         = "jatin-s3-shopnow-tfstate"
  key            = "capstone-eks-deployment/terraform.tfstate"  # ✅ New, unique path
  region         = "eu-west-2"
  dynamodb_table = "jatin-shopnow-statelock"
  encrypt        = true
}
```

**Benefits:**
- ✅ Keeps existing state files intact
- ✅ No risk of overwriting old infrastructure
- ✅ Can manage multiple deployments in same bucket
- ✅ Clear separation of concerns

**How to Apply:**
1. Edit `eks-tf/provider.tf` line 23
2. Change `"terraform/terraform.tfstate"` to `"capstone-eks-deployment/terraform.tfstate"`
3. Save file
4. Run `terraform init -reconfigure`

---

## ⚠️ OPTION 2: Delete Existing State (FRESH START)

**Only use this if:**
- You're certain old state files are not needed
- You want to completely start over
- You've verified no important infrastructure is tracked in old state

### Commands to Delete Old State

```bash
# 1. List what's in the bucket
aws s3 ls s3://jatin-s3-shopnow-tfstate/ --recursive

# 2. Check if there are any state files
aws s3 ls s3://jatin-s3-shopnow-tfstate/terraform/

# Output might show:
# terraform.tfstate
# terraform.tfstate.backup

# 3. BACKUP first (IMPORTANT!)
aws s3 cp s3://jatin-s3-shopnow-tfstate/terraform/terraform.tfstate \
  ./backup-terraform.tfstate.$(date +%Y%m%d)

# 4. Delete old state files
aws s3 rm s3://jatin-s3-shopnow-tfstate/terraform/terraform.tfstate
aws s3 rm s3://jatin-s3-shopnow-tfstate/terraform/terraform.tfstate.backup

# 5. DynamoDB locks expire automatically, but you can list them:
aws dynamodb scan --table-name jatin-shopnow-statelock

# If you see any locks, they'll auto-expire or delete with:
aws dynamodb delete-item --table-name jatin-shopnow-statelock --key '{"LockID":{"S":"<lock-id>"}}'
```

**After deletion:**
- Keep current `provider.tf` configuration as-is
- Run `terraform init`
- Run `terraform apply`

---

## 🔍 Verify S3 Bucket Before Proceeding

```bash
# Check what's currently in your S3 bucket
aws s3 ls s3://jatin-s3-shopnow-tfstate/ --recursive

# Expected output (if empty):
# (nothing)

# Or (if has existing state):
# terraform/terraform.tfstate
# terraform/terraform.tfstate.backup

# Check DynamoDB table exists
aws dynamodb describe-table --table-name jatin-shopnow-statelock

# Expected output:
# {
#   "Table": {
#     "TableName": "jatin-shopnow-statelock",
#     "KeySchema": [...],
#     "TableStatus": "ACTIVE",
#     ...
#   }
# }
```

---

## 📋 Decision Matrix

| Situation | Recommendation | Action |
|-----------|---------------|--------|
| **Don't know what's in old state** | Use Option 1 | Change state key to `capstone-eks-deployment/terraform.tfstate` |
| **Old state manages important infrastructure** | Use Option 1 | Change state key to `capstone-eks-deployment/terraform.tfstate` |
| **Old state is empty or not needed** | Use Option 2 | Delete old state files, keep current key |
| **Want to keep all deployments in one bucket** | Use Option 1 | Use different keys for different environments |
| **Starting completely fresh** | Either works | Option 1 is safer |

---

## 🎯 My Recommendation for You

**Use OPTION 1** because:
1. ✅ Safe - won't break anything
2. ✅ Flexible - can keep both old and new state
3. ✅ Professional - matches real-world practices
4. ✅ No risk - old infrastructure remains untouched

**Implementation:**

```bash
# 1. Edit provider.tf
nano eks-tf/provider.tf  # Or use VS Code

# 2. Change line 23 from:
key = "terraform/terraform.tfstate"

# To:
key = "capstone-eks-deployment/terraform.tfstate"

# 3. Initialize with new backend
cd eks-tf
terraform init -reconfigure

# Output should show:
# Initializing the backend...
# Successfully configured the backend "s3"!

# 4. Proceed with deployment
terraform plan -var-file=demo.tfvars
terraform apply -var-file=demo.tfvars
```

---

## 🧪 After Deployment - Verify State Location

```bash
# Check new state file was created in correct location
aws s3 ls s3://jatin-s3-shopnow-tfstate/capstone-eks-deployment/

# Should show:
# terraform.tfstate

# Download and inspect (optional)
aws s3 cp s3://jatin-s3-shopnow-tfstate/capstone-eks-deployment/terraform.tfstate - | jq '.version'
# Should show: 4 (Terraform state version)
```

---

## 📝 Summary

**What to do:**
1. Edit `eks-tf/provider.tf` line 23
2. Change key to `"capstone-eks-deployment/terraform.tfstate"`
3. Run `terraform init -reconfigure`
4. Proceed with deployment

**Time required:** 2 minutes
**Risk:** None (old state untouched)
**Benefit:** Clean, isolated deployment

---

**Next step:** Open [`eks-tf/provider.tf`](file:///d:/HeroVired/shopNow-Capstone/eks-tf/provider.tf) and make the change!
